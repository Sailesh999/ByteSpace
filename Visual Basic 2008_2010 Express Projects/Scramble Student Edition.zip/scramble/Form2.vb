﻿Public Class Form2


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        GroupBox2.Visible = True
        GroupBox2.Width = 452
        GroupBox2.Height = 101
        Label7.Text = "user name"
        TextBox1.PasswordChar = ""
        TextBox1.ResetText()
        GroupBox2.Text = "System Settings"
    End Sub

    

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        If Saileswar_mahakud_as_sailesh.Created = False Then
            Saileswar_mahakud_as_sailesh.Show()
        Else
            If Saileswar_mahakud_as_sailesh.s_cl <> Saileswar_mahakud_as_sailesh.s_li Then
                If Saileswar_mahakud_as_sailesh.s_fs = False Then
                    MsgBox(" you have opted to change language: you may save current unsaved file by selecting save as... in the new environment", MsgBoxStyle.Information)

                End If

                Saileswar_mahakud_as_sailesh.Hide()
                set_help_sailesh()

                Saileswar_mahakud_as_sailesh.Show()


            End If

        End If


        Me.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        GroupBox2.Visible = True
        GroupBox2.Width = 452
        GroupBox2.Height = 101
        Label7.Text = "old password"

        TextBox1.PasswordChar = "*"
        TextBox1.ResetText()
        GroupBox2.Text = "Current User Account Settings"
    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click
        If Saileswar_mahakud_as_sailesh.Created = False Then
            End
        Else
            Me.Close()
        End If

    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        GroupBox2.Visible = False
    End Sub

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Button4.Text = My.Computer.FileSystem.CurrentDirectory
        If Saileswar_mahakud_as_sailesh.Created = False Then
            Button6.Text = Form1.ComboBox1.Text
        End If

        Label11.Text = Form1.TextBox1.Text
        Me.Width = 722
        Me.Height = 222
        Label13.Text = "Working space: " & Environment.WorkingSet & "  Bytes"
        Label12.Text = "Number of Processor(s): " & Environment.ProcessorCount
        Label14.Text = "OS: " & My.Computer.Info.OSFullName

    End Sub




    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If FolderBrowserDialog1.ShowDialog() = DialogResult.OK Then
            Button4.Text = FolderBrowserDialog1.SelectedPath
            Try
                ChDir(Button4.Text)
            Catch ex As Exception

            End Try

        End If
        Button4.Text = My.Computer.FileSystem.CurrentDirectory

    End Sub



    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        ComboBox1.Visible = True
        ComboBox1.DroppedDown = True
    End Sub

    Private Sub ComboBox1_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox1.TextChanged
        If ComboBox1.Text <> "" And Trim(ComboBox1.Text) <> "select language" Then

            Button6.Text = ComboBox1.Text

            ComboBox1.Visible = False
            Me.Refresh()
        End If
        Me.Refresh()
    End Sub



    Private Sub Label1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label1.MouseEnter
        Label1.BackColor = Color.Tomato
    End Sub

    Private Sub Label1_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label1.MouseLeave
        Label1.BackColor = Color.Crimson
    End Sub



    Private Sub Button6_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button6.MouseEnter
        Label20.Visible = True
    End Sub

    Private Sub Button6_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button6.MouseLeave
        Label20.Visible = False
    End Sub

    Private Sub Button6_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button6.TextChanged
        If Button6.Text = "C / C++ 16 bit turbo" Then

            Saileswar_mahakud_as_sailesh.s_li = 1
        End If
        If Button6.Text = "Oracle-Sun Java" Then

            Saileswar_mahakud_as_sailesh.s_li = 2
        End If
        If Button6.Text = "C / C++ AVR C/C++" Then

            Saileswar_mahakud_as_sailesh.s_li = 3
        End If
        If Button6.Text = "C / C++ AVR GCC" Then

            Saileswar_mahakud_as_sailesh.s_li = 4
        End If
        If Button6.Text = "HTML / Jscript / VB script" Then

            Saileswar_mahakud_as_sailesh.s_li = 5
        End If
    End Sub

    Private Sub Label19_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label19.Click
        Dim s As String
        s = "explorer " & Button4.Text
        Shell(s, AppWinStyle.NormalFocus)
    End Sub

    Private Sub Button4_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.MouseEnter
        Label20.Visible = True
    End Sub

    Private Sub Button4_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.MouseLeave
        Label20.Visible = False
    End Sub


    Private Sub Form2_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        If Saileswar_mahakud_as_sailesh.Created = True Then
            set_made_on_23feb_2011()
        End If
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub
End Class