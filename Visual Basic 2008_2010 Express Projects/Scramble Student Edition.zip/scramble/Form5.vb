﻿Imports System.IO

Public Class Saileswar_mahakud_as_sailesh
    Public s_li As Integer = 0
    Public s_cl As Integer = 0
    Public fname As String = ""
    Public s_fr = True

    Dim s_ls As String = ""
    Public s_fs As Boolean = False


    Public muna1 As Boolean = False
    Public muna2 As Boolean = False
    Public muna3 As Boolean = False
    Public muna4 As Boolean = False
    Public muna5 As Boolean = False


    Private Sub Form5_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        End
    End Sub

    Private Sub Form5_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        Try
            If sailesh13.HasExited = False Then
                Dim to_kill As String
                to_kill = Label1.Text & sailesh13.Id
                Shell(to_kill)
                MsgBox(Label2.Text, MsgBoxStyle.Information)

            End If

        Catch ex As Exception

        End Try



        If s_fs = False Then
            If MsgBox(Label5.Text, MsgBoxStyle.Information) = MsgBoxResult.Ok Then
            Else
                End
            End If

        End If
    End Sub


    Private Sub Form5_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sailesh15.Start()






    End Sub

    Private Sub DashboardToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a4.Click
        Form2.ShowDialog()
    End Sub

    Private Sub DashboardToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a11.Click
        Form2.ShowDialog()
    End Sub

    Private Sub DashboardToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DashboardToolStripMenuItem2.Click
        Form2.ShowDialog()
    End Sub

    Private Sub DashboardToolStripMenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DashboardToolStripMenuItem3.Click
        Form2.ShowDialog()
    End Sub

    Private Sub DashboardToolStripMenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DashboardToolStripMenuItem4.Click
        Form2.ShowDialog()
    End Sub



    Private Sub ToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AppLaunchrToolStripButton1.Click
        Try
            Shell(a99.Text, AppWinStyle.NormalFocus)
        Catch ex As Exception

        End Try

    End Sub

    Private Sub NewToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a12.Click
        editorTextBox1.ResetText()

        If muna1 = True Then

            editorTextBox1.Text = C_CPPtmplte.Text
        ElseIf muna2 = True Then
            editorTextBox1.Text = TextBox4.Text
        End If
    End Sub

    Private Sub CutToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a40.Click
        editorTextBox1.Cut()
    End Sub

    Private Sub CopyToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a41.Click
        editorTextBox1.Copy()
    End Sub

    Private Sub PasteToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a42.Click
        editorTextBox1.Paste()
    End Sub

    Private Sub ToolStripButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton4.Click
        If editorTextBox1.WordWrap = True Then
            editorTextBox1.WordWrap = False
        ElseIf editorTextBox1.WordWrap = False Then
            editorTextBox1.WordWrap = True
        End If
    End Sub


    Private Sub ToolStripTextBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripTextBox1.Click
        sailesh10.ShowColor = True
        sailesh10.ShowApply = True
        sailesh10.ShowEffects = True
        sailesh10.ShowHelp = True
        sailesh10.AllowVectorFonts = True
        sailesh10.ShowDialog()
    End Sub

    Private Sub NumericUpDown1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a47.ValueChanged

        Try
            Dim f As New System.Drawing.Font(editorTextBox1.Font.Name, a47.Value)
            editorTextBox1.Font = f
        Catch ex As Exception
            MsgBox(Label6.Text, MsgBoxStyle.Information)
        End Try

    End Sub

    Private Sub NewToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewToolStripButton1.Click
        DocWebBrowser1.Navigate(DocLaunchrTextBox2.Text)
    End Sub

    Private Sub DocLaunchrTextBox2_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles DocLaunchrTextBox2.KeyDown
        If e.KeyCode = Keys.Enter Then
            NewToolStripButton1.PerformClick()
        End If
    End Sub


    Private Sub applauncher_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles a99.KeyDown
        If e.KeyCode = Keys.Enter Then
            AppLaunchrToolStripButton1.PerformClick()
        End If
    End Sub

    Private Sub ToolStripButton1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton1.Click
        editorTextBox1.Undo()
    End Sub

    Private Sub ToolStripButton5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a30.Click
        editorTextBox1.Redo()
    End Sub

    Private Sub ToolStripButton6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a45.Click
        editorTextBox1.SelectAll()
    End Sub



    Private Sub editorRichTextBox1_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles editorTextBox1.KeyUp
        If muna5 = False Then
            If e.KeyCode = Keys.OemSemicolon Then

                If ToolStripLabel7.Text <> " " And ToolStripLabel1.Text <> "filename" Then


                Else
                    MsgBox(Label7.Text)

                End If
            End If

        End If

    End Sub

    Private Sub editorRichTextBox1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles editorTextBox1.MouseEnter
        Me.Opacity = 1
        Me.Refresh()
    End Sub



    Private Sub editorRichTextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles editorTextBox1.TextChanged
        ToolStripLabel10.Text = editorTextBox1.Lines.Count
        If editorTextBox1.CanUndo = True Then
            ToolStripButton1.Enabled = True
        Else
            ToolStripButton1.Enabled = False
        End If
        If editorTextBox1.CanRedo Then
            a30.Enabled = True
        Else
            a30.Enabled = False
        End If


        If muna5 = True Then
            DocWebBrowser1.DocumentText = editorTextBox1.Text

        End If

        s_fs = False
        ToolStripLabel6.Text = "unsaved document"
    End Sub

    Private Sub ToolStripButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a46.Click
        If muna5 = True Then
            If SplitContainer1.Orientation = Orientation.Horizontal Then
                SplitContainer1.Orientation = Orientation.Vertical
            Else
                SplitContainer1.Orientation = Orientation.Horizontal
            End If


        Else
            If SplitContainer1.Panel2Collapsed = True Then
                SplitContainer1.Panel2Collapsed = False
            ElseIf SplitContainer1.Panel2Collapsed = False Then
                SplitContainer1.Panel2Collapsed = True
            End If
        End If


    End Sub



    Private Sub CompileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a2.Click
        SplitContainer1.Panel2Collapsed = True
        Try
            a1.PerformClick()
            editorTextBox1.ReadOnly = True
        Catch ex As Exception

        End Try
        set_uia()
        Try
            runtime_form.ShowDialog()
        Catch ex As Exception

        End Try




        editorTextBox1.ReadOnly = False
    End Sub


    Private Sub SaveToolStripMenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a1.Click
        Try
            If ToolStripLabel7.Text = " " Then
                MsgBox("please select file type")
                Panel1.BackColor = Color.DarkRed
                Panel1.ForeColor = Color.White

            End If
            Me.Cursor = Cursors.WaitCursor
            ToolStripLabel6.Text = "saving...."
            s_ls = Now.ToString
            fname = ToolStripTextBox2.Text & ToolStripLabel7.Text
            REM  MsgBox(fname)
            editorTextBox1.SaveFile(fname, RichTextBoxStreamType.PlainText)
            Me.Cursor = Cursors.Arrow
            ToolStripLabel6.Text = "file saved:"
            ToolStripLabel1.Text = ToolStripTextBox2.Text
            Me.Text = "bytespace beta 1.0 - " & fname & "-last saved @ " & s_ls
            a2.Enabled = True
        Catch ex As Exception
            MsgBox("exception:file could not be saved", MsgBoxStyle.Information)
            ToolStripLabel6.Text = "file could not be saved:"
        End Try

    End Sub



    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        Label3.Visible = False
        Label4.Visible = False


        If muna1 = True Then
            If TextBox1.Text.Contains("Error") Then
                TextBox1.ForeColor = Color.Red
                a3.Enabled = False
                Label3.Visible = True

            ElseIf TextBox1.Text.Contains("Warning") Then
                TextBox1.ForeColor = Color.SeaGreen
                a3.Enabled = True
                Label4.Visible = True

            Else
                Me.BackColor = Color.Navy
                TextBox1.ForeColor = Color.White
                a3.Enabled = True
            End If

        ElseIf muna2 = True Then
            If TextBox1.Text.Contains("error") Or TextBox1.Text.Contains("reached end of file") Or TextBox1.Text.Contains("expected") Then
                TextBox1.ForeColor = Color.Red
                a3.Enabled = False
                Label3.Visible = True

            Else
                Me.BackColor = Color.Navy
                TextBox1.ForeColor = Color.White
                a10.Enabled = True
            End If
        End If

    End Sub




    Private Sub RadioButton3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton3.CheckedChanged
        If RadioButton3.Checked = True Then
            ToolStripLabel7.Text = ".java"
        End If
    End Sub

    Private Sub RadioButton4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton4.CheckedChanged
        If RadioButton4.Checked = True Then
            ToolStripLabel7.Text = ".txt"
        End If
    End Sub

    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked = True Then
            ToolStripLabel7.Text = ".c"
        End If
    End Sub

    Private Sub RadioButton2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton2.CheckedChanged
        If RadioButton2.Checked = True Then
            ToolStripLabel7.Text = ".cpp"
        End If
    End Sub


    Private Sub ToolStripLabel7_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ToolStripLabel7.TextChanged
        Panel1.BackColor = Color.White
        Panel1.ForeColor = Color.Navy
    End Sub

    Private Sub ToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a3.Click


        set_uia()

        Dim arg As String
        arg = ToolStripTextBox7.Text
        editorTextBox1.ReadOnly = True
        Dim path As String
        path = ToolStripTextBox2.Text & ".exe"
        REM MsgBox(path)
        runtime_form.Button3.Text = "load"

        Try

            sailesh13.StartInfo.FileName = Label10.Text
            sailesh13.StartInfo.Arguments = Label8.Text & path & " " & arg & "  & pause "
            sailesh13.StartInfo.UseShellExecute = True
            sailesh13.StartInfo.WindowStyle = ProcessWindowStyle.Normal

            sailesh13.Start()


        Catch ex As Exception

        End Try
        editorTextBox1.ReadOnly = False

    End Sub

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenToolStripMenuItem.Click
        a13.PerformClick()
    End Sub

    Private Sub NewToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewToolStripMenuItem.Click
        editorTextBox1.Text = C_CPPtmplte.Text
    End Sub



    Private Sub ToolStripLabel10_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ToolStripLabel10.TextChanged
        If ToolStripLabel10.Text > 9 Then
            If muna5 = False Then


                If ToolStripLabel7.Text <> " " And ToolStripLabel1.Text <> "filename" Then

                Else
                    MsgBox(" please save the file first")

                End If


            End If
        End If


    End Sub





    Private Sub ToolStripLabel6_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ToolStripLabel6.TextChanged
        If muna5 = True Then
            ToolStripTextBox6.BackColor = Color.MediumPurple
            SaveToolStripMenuItem.BackColor = Color.Transparent
            SaveToolStripMenuItem.ForeColor = Color.Black
        End If
        s_fs = True
    End Sub


    Private Sub SaveToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripButton1.Click
        DocWebBrowser1.ShowSaveAsDialog()
    End Sub

    Private Sub PrintToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintToolStripButton1.Click
        DocWebBrowser1.ShowPrintDialog()
    End Sub


    Private Sub PrintOptionsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a19.Click
        Dim print_text As String
        If muna5 = True Then
            DocWebBrowser1.ShowPrintDialog()
        Else
            ide_engine_WebBrowser1.Navigate(CurDir)
            print_text = "<html><head><title>" & ToolStripTextBox2.Text & ToolStripLabel7.Text & "</title></head>" & "<body>" & editorTextBox1.Text & "</body></html>"
            ide_engine_WebBrowser1.DocumentText = print_text
            MsgBox(print_text)
            ide_engine_WebBrowser1.ShowPrintDialog()
        End If


    End Sub

    Private Sub PrintPreviewToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a20.Click
        If muna5 = True Then
            DocWebBrowser1.ShowPrintPreviewDialog()
        Else
            ide_engine_WebBrowser1.DocumentText = editorTextBox1.Text
            ide_engine_WebBrowser1.ShowPrintPreviewDialog()
        End If

    End Sub

    Private Sub PrintToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a21.Click
        If muna5 = True Then
            DocWebBrowser1.Print()
        Else
            ide_engine_WebBrowser1.Print()
        End If

    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a14.Click
        If muna5 = True Then
            DocWebBrowser1.ShowSaveAsDialog()
        Else

            sailesh18.Filter = "txt files (*.txt)|*.txt|c files (*.c)|*.c| c++ files (*.cpp)|*.cpp|All files (*.*)|*.*"
            sailesh18.FilterIndex = 2
            sailesh18.RestoreDirectory = True
            If (sailesh18.ShowDialog() = DialogResult.OK) Then
                editorTextBox1.SaveFile(sailesh18.FileName, RichTextBoxStreamType.PlainText)

            End If


        End If

    End Sub

    Private Sub SaveToolStripMenuItem10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a15.Click
        If muna1 = True Then
            a1.PerformClick()

        ElseIf muna2 = True Then

            a90.PerformClick()

        ElseIf muna5 = True Then
            SaveToolStripButton1.PerformClick()
        End If
    End Sub

    Private Sub Form5_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown


        set_help_sailesh()




    End Sub


    Private Sub PrintToolStripButton_ButtonClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a18.ButtonClick
        If muna5 = True Then
            PrintToolStripButton1.PerformClick()
        End If

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sailesh15.Tick
        a15.PerformClick()
    End Sub


    Private Sub SaveToolStripButton_ButtonClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a16.ButtonClick
        a15.PerformClick()
    End Sub

    Private Sub ToolStripLabel10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripLabel10.Click

    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem.Click
        SaveToolStripButton1.PerformClick()
        ToolStripLabel6.Visible = False
    End Sub

    Private Sub MenuStrip5_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles sailesh4.ItemClicked

    End Sub

    Private Sub ToolStrip1_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles sailesh6.ItemClicked

    End Sub

    Private Sub OpenToolStripButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles a13.Click
        register.ShowDialog()

    End Sub

    Private Sub ToolStripLabel7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripLabel7.Click

    End Sub

    Private Sub SaveToolStripMenuItem5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem5.Click
        a16.PerformClick()
    End Sub

    Private Sub NewToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewToolStripMenuItem1.Click
        a12.PerformClick()
    End Sub

    Private Sub SaveToolStripMenuItem6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem6.Click
        a90.PerformClick()
    End Sub

    Private Sub OpenToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenToolStripMenuItem1.Click
        register.ShowDialog()
    End Sub

    Private Sub NewToolStripMenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewToolStripMenuItem4.Click
        a12.PerformClick()
    End Sub

    Private Sub SaveToolStripMenuItem9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem9.Click
        a16.PerformClick()
    End Sub

    Private Sub ToolStripMenuItem69_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem69.Click
        Me.Close()
    End Sub

    Private Sub ExitToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem1.Click
        Me.Close()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub SaveToolStripMenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a90.Click
        Try
            If ToolStripLabel7.Text = " " Then
                MsgBox("please select file type")
                Panel1.BackColor = Color.DarkRed
                Panel1.ForeColor = Color.White

            End If
            Me.Cursor = Cursors.WaitCursor
            ToolStripLabel6.Text = "saving...."
            s_ls = Now.ToString
            fname = ToolStripTextBox3.Text & ToolStripLabel7.Text
            REM  MsgBox(fname)
            editorTextBox1.SaveFile(fname, RichTextBoxStreamType.PlainText)
            Me.Cursor = Cursors.Arrow
            ToolStripLabel6.Text = "file saved:"
            ToolStripLabel1.Text = ToolStripTextBox3.Text
            Me.Text = "bytespace beta 1.0 - " & fname & "-last saved @ " & s_ls
            a2.Enabled = True
        Catch ex As Exception
            MsgBox("exception:file could not be saved", MsgBoxStyle.Information)
            ToolStripLabel6.Text = "file could not be saved:"
        End Try
    End Sub

    Private Sub CompileToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a9.Click
        SplitContainer1.Panel2Collapsed = True
        Try
            a90.PerformClick()
            editorTextBox1.ReadOnly = True
        Catch ex As Exception

        End Try
        set_made_by_saileswar_kumar_mahakud()
        Try
            runtime_form.ShowDialog()
        Catch ex As Exception

        End Try




        editorTextBox1.ReadOnly = False
    End Sub

    Private Sub ToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles a10.Click
        REM    execute processs

        set_made_by_saileswar_kumar_mahakud()
        Dim arg As String
        arg = ToolStripTextBox8.Text
        editorTextBox1.ReadOnly = True
        Dim path As String
        path = Trim(ToolStripTextBox3.Text)
        REM MsgBox(path)
        runtime_form.Button3.Text = "load"

        Try

            sailesh20.StartInfo.FileName = Label10.Text
            sailesh20.StartInfo.Arguments = Label9.Text & path & " " & arg & " & pause"
            sailesh20.StartInfo.UseShellExecute = True
            sailesh20.StartInfo.WindowStyle = ProcessWindowStyle.Normal

            sailesh20.Start()


        Catch ex As Exception

        End Try
        editorTextBox1.ReadOnly = False

    End Sub

    Private Sub ToolStripLabel8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripLabel8.Click

    End Sub
End Class