﻿Module ide_bckgrnd_wrkr

    Function set_uia() As Integer
        Dim path As String
        path = My.Computer.FileSystem.CurrentDirectory
        Saileswar_mahakud_as_sailesh.sailesh12.StartInfo.WorkingDirectory = path


        Saileswar_mahakud_as_sailesh.sailesh12.StartInfo.FileName = "cmd"
        Saileswar_mahakud_as_sailesh.sailesh12.StartInfo.Arguments = Saileswar_mahakud_as_sailesh.TextBox3.Text & Saileswar_mahakud_as_sailesh.fname

        Saileswar_mahakud_as_sailesh.sailesh12.StartInfo.CreateNoWindow = True
        Saileswar_mahakud_as_sailesh.sailesh12.StartInfo.UseShellExecute = False
        Saileswar_mahakud_as_sailesh.sailesh12.StartInfo.RedirectStandardOutput = True
        Try
            Saileswar_mahakud_as_sailesh.a1.PerformClick()
        Catch ex As Exception

        End Try
        Try
            Saileswar_mahakud_as_sailesh.sailesh12.Start()

            Saileswar_mahakud_as_sailesh.sailesh12.WaitForExit()

            runtime_form.TextBox2.Visible = True
            If Saileswar_mahakud_as_sailesh.sailesh12.HasExited = True Then
                runtime_form.Label2.Text = "file successfully compiled"
                runtime_form.PictureBox1.Visible = False
            End If

            runtime_form.TextBox2.Text = Saileswar_mahakud_as_sailesh.sailesh12.StandardOutput.ReadToEnd()
            Saileswar_mahakud_as_sailesh.TextBox1.Text = Saileswar_mahakud_as_sailesh.outpt_tmplte_TextBox2.Text & vbNewLine & runtime_form.TextBox2.Text


            runtime_form.TextBox2.ScrollBars = ScrollBars.Vertical
        Catch ex As Exception
            MsgBox("exception: file could not be compiled", MsgBoxStyle.Critical)
        End Try
        Return 0
    End Function




    Function set_help_sailesh() As Integer

        Saileswar_mahakud_as_sailesh.muna1 = False
        Saileswar_mahakud_as_sailesh.muna2 = False
        Saileswar_mahakud_as_sailesh.muna3 = False
        Saileswar_mahakud_as_sailesh.muna4 = False
        Saileswar_mahakud_as_sailesh.muna5 = False

        If Saileswar_mahakud_as_sailesh.s_li = 1 Then          REM C / C++ 16 bit turbo
            Saileswar_mahakud_as_sailesh.sailesh1.Visible = True
            Saileswar_mahakud_as_sailesh.sailesh2.Visible = False
            Saileswar_mahakud_as_sailesh.sailesh3.Visible = False
            Saileswar_mahakud_as_sailesh.sailesh4.Visible = False
            Saileswar_mahakud_as_sailesh.sailesh5.Visible = False
            Saileswar_mahakud_as_sailesh.Panel1.Visible = True
            Saileswar_mahakud_as_sailesh.sailesh15.Enabled = True
            Saileswar_mahakud_as_sailesh.muna1 = True
        End If
        If Saileswar_mahakud_as_sailesh.s_li = 2 Then          REM Oracle-Sun Java
            Saileswar_mahakud_as_sailesh.sailesh2.Visible = True
            Saileswar_mahakud_as_sailesh.sailesh1.Visible = False
            Saileswar_mahakud_as_sailesh.sailesh3.Visible = False
            Saileswar_mahakud_as_sailesh.sailesh4.Visible = False
            Saileswar_mahakud_as_sailesh.sailesh5.Visible = False
            Saileswar_mahakud_as_sailesh.Panel1.Visible = True
            Saileswar_mahakud_as_sailesh.muna2 = True
            Saileswar_mahakud_as_sailesh.sailesh15.Enabled = True
        End If
        If Saileswar_mahakud_as_sailesh.s_li = 3 Then          REM C / C++ AVR C/C++
            Saileswar_mahakud_as_sailesh.sailesh3.Visible = True
            Saileswar_mahakud_as_sailesh.sailesh2.Visible = False
            Saileswar_mahakud_as_sailesh.sailesh1.Visible = False
            Saileswar_mahakud_as_sailesh.sailesh4.Visible = False
            Saileswar_mahakud_as_sailesh.sailesh5.Visible = False
            Saileswar_mahakud_as_sailesh.Panel1.Visible = True
            Saileswar_mahakud_as_sailesh.muna3 = True
            Saileswar_mahakud_as_sailesh.sailesh15.Enabled = True
        End If
        If Saileswar_mahakud_as_sailesh.s_li = 4 Then          REM C / C++ AVR GCC
            Saileswar_mahakud_as_sailesh.sailesh5.Visible = True
            Saileswar_mahakud_as_sailesh.sailesh2.Visible = False
            Saileswar_mahakud_as_sailesh.sailesh3.Visible = False
            Saileswar_mahakud_as_sailesh.sailesh1.Visible = False
            Saileswar_mahakud_as_sailesh.sailesh4.Visible = False
            Saileswar_mahakud_as_sailesh.Panel1.Visible = True
            Saileswar_mahakud_as_sailesh.muna4 = True
            Saileswar_mahakud_as_sailesh.sailesh15.Enabled = True
        End If
        If Saileswar_mahakud_as_sailesh.s_li = 5 Then          REM HTML / Jscript / VB script
            Saileswar_mahakud_as_sailesh.sailesh4.Visible = True
            Saileswar_mahakud_as_sailesh.sailesh2.Visible = False
            Saileswar_mahakud_as_sailesh.sailesh3.Visible = False
            Saileswar_mahakud_as_sailesh.sailesh5.Visible = False
            Saileswar_mahakud_as_sailesh.sailesh1.Visible = False
            Saileswar_mahakud_as_sailesh.Panel1.Visible = False
            Saileswar_mahakud_as_sailesh.muna5 = True
            Saileswar_mahakud_as_sailesh.TabPage2.BringToFront()
            Saileswar_mahakud_as_sailesh.sailesh15.Enabled = False
        End If
        Saileswar_mahakud_as_sailesh.TextBox1.Text = ""
        Saileswar_mahakud_as_sailesh.SplitContainer2.Panel1Collapsed = True
        Saileswar_mahakud_as_sailesh.ToolStripTextBox1.Text = Saileswar_mahakud_as_sailesh.editorTextBox1.Font.Name
        Saileswar_mahakud_as_sailesh.a47.Value = Saileswar_mahakud_as_sailesh.editorTextBox1.Font.SizeInPoints
        Return 0
    End Function


    Function set_made_on_23feb_2011() As Integer

        If Saileswar_mahakud_as_sailesh.s_li = 1 Then
            Form2.Button6.Text = "C / C++ 16 bit turbo"
        ElseIf Saileswar_mahakud_as_sailesh.s_li = 2 Then
            Form2.Button6.Text = "Oracle-Sun Java"
        ElseIf Saileswar_mahakud_as_sailesh.s_li = 3 Then
            Form2.Button6.Text = "C / C++ AVR C/C++"
        ElseIf Saileswar_mahakud_as_sailesh.s_li = 4 Then
            Form2.Button6.Text = "C / C++ AVR GCC"
        ElseIf Saileswar_mahakud_as_sailesh.s_li = 5 Then
            Form2.Button6.Text = "HTML / Jscript / VB script"
        End If

        Return 0

    End Function


    Function set_made_by_saileswar_kumar_mahakud() As Integer
        Dim path As String
        path = My.Computer.FileSystem.CurrentDirectory
        Saileswar_mahakud_as_sailesh.sailesh19.StartInfo.WorkingDirectory = path


        Saileswar_mahakud_as_sailesh.sailesh19.StartInfo.FileName = "cmd"
        Saileswar_mahakud_as_sailesh.sailesh19.StartInfo.Arguments = Saileswar_mahakud_as_sailesh.TextBox2.Text & Saileswar_mahakud_as_sailesh.fname & " & pause"


        Saileswar_mahakud_as_sailesh.sailesh19.StartInfo.CreateNoWindow = True
        Saileswar_mahakud_as_sailesh.sailesh19.StartInfo.UseShellExecute = False
        Saileswar_mahakud_as_sailesh.sailesh19.StartInfo.RedirectStandardOutput = True
        Saileswar_mahakud_as_sailesh.sailesh19.StartInfo.RedirectStandardError = True

        Try
            Saileswar_mahakud_as_sailesh.a90.PerformClick()
        Catch ex As Exception

        End Try
        Try
            Saileswar_mahakud_as_sailesh.sailesh19.Start()
            runtime_form.TextBox2.Text = Saileswar_mahakud_as_sailesh.sailesh19.StandardError.ReadToEnd()
            runtime_form.TextBox2.Visible = True

            If Saileswar_mahakud_as_sailesh.sailesh19.HasExited = True Then
                runtime_form.Label2.Text = "file successfully compiled"
                runtime_form.PictureBox1.Visible = False
            End If

            Saileswar_mahakud_as_sailesh.TextBox1.Text = Saileswar_mahakud_as_sailesh.outpt_tmplte_TextBox2.Text & vbNewLine & runtime_form.TextBox2.Text


            runtime_form.TextBox2.ScrollBars = ScrollBars.Vertical
        Catch ex As Exception
            MsgBox("exception: file could not be compiled", MsgBoxStyle.Critical)
        End Try
        Return 0
    End Function


End Module
