﻿Public Class runtime_form
    Private mouseOffset As Point
    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click
        Me.Close()
    End Sub

    
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If Saileswar_mahakud_as_sailesh.muna2 = True Then
            Saileswar_mahakud_as_sailesh.a10.PerformClick()
        ElseIf Saileswar_mahakud_as_sailesh.muna1 = True Then

            Saileswar_mahakud_as_sailesh.a3.PerformClick()
        End If

        Button2.Enabled = True
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Try
            Me.TopMost = False
            Dim path As String
            path = "explorer " & CurDir()
            Shell(path, AppWinStyle.NormalFocus)

        Catch ex As Exception

        End Try

    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged
        Label3.Visible = False
        Label3.Visible = False
        If TextBox2.Text.Contains("Warning") Then
            Label4.Visible = True
        End If
        If TextBox2.Text.Contains("Error") Then
            Label3.Visible = True
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click

        If Saileswar_mahakud_as_sailesh.a3.Enabled = True Or Saileswar_mahakud_as_sailesh.a10.Enabled = True Then
            Me.Hide()
            debug_help.RichTextBox1.Text = Saileswar_mahakud_as_sailesh.editorTextBox1.Text
            debug_help.TextBox1.Text = Saileswar_mahakud_as_sailesh.TextBox1.Text

            debug_help.ShowDialog()
            Me.Close()

        End If

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try

            If Saileswar_mahakud_as_sailesh.sailesh13.HasExited = False Then
                Dim resp As MsgBoxResult
                resp = MsgBox("Terminate running program?",
                  MsgBoxStyle.YesNo, "Terminate?")

                Dim to_kill As String
                If resp = MsgBoxResult.Yes Then



                    to_kill = "taskkill /f /t /pid " & Saileswar_mahakud_as_sailesh.sailesh13.Id


                    Shell(to_kill)
                End If

            End If

            If Saileswar_mahakud_as_sailesh.sailesh20.HasExited = False Then
                Dim resp As MsgBoxResult
                resp = MsgBox("Terminate running program?",
                  MsgBoxStyle.YesNo, "Terminate?")

                Dim to_kill As String
                If resp = MsgBoxResult.Yes Then
                    to_kill = "taskkill /f /t /pid " & Saileswar_mahakud_as_sailesh.sailesh20.Id

                    Shell(to_kill)
                End If
            End If


        Catch ex As Exception
            Me.Close()
        End Try

    End Sub



    Private Sub runtime_form_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        Saileswar_mahakud_as_sailesh.SplitContainer1.Panel2Collapsed = False
    End Sub

    Private Sub Label1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label1.MouseEnter
        Label1.BackColor = Color.Maroon
    End Sub

    Private Sub Label1_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label1.MouseLeave
        Label1.BackColor = Color.Tomato
    End Sub

    Private Sub RectangleShape1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RectangleShape1.Click

    End Sub

    Private Sub RectangleShape1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles RectangleShape1.MouseDown
        mouseOffset = New Point(-e.X, -e.Y)
    End Sub

    Private Sub RectangleShape1_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles RectangleShape1.MouseMove
        If e.Button = Windows.Forms.MouseButtons.Left Then
            Dim mousePos As Point = Control.MousePosition
            mousePos.Offset(mouseOffset.X, mouseOffset.Y)
            Location = mousePos
        End If
    End Sub
End Class