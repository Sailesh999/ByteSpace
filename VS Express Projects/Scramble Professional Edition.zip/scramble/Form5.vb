﻿Imports System.IO

Public Class Form5
    Public language_index As Integer = 0
    Public current_language As Integer = 0
    Public fname As String = ""
    Public file_runing = True

    Dim last_saved As String = ""
    Public file_saved As Boolean = False


    Public t16_bit_turboc_flag As Boolean = False
    Public Jv_bit_flag As Boolean = False
    Public avrc_flag As Boolean = False
    Public avrgcc_flag As Boolean = False
    Public html_flag As Boolean = False
    Public stck_trce As String

    


    Private Sub Form5_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        End
    End Sub

    Private Sub Form5_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        Try
            If execute_TC_Process2.HasExited = False Then
                Dim to_kill As String
                to_kill = "taskkill /f /t /pid " & execute_TC_Process2.Id
                Shell(to_kill)
                MsgBox("Closing Application in debugging mode may result in catastrophic errors.Please ensure safe application shutdown", MsgBoxStyle.Information)

            End If

        Catch ex As Exception

        End Try
        Try
            If execute_JV_Process2.HasExited = False Then
                Dim to_kill As String
                to_kill = "taskkill /f /t /pid " & execute_JV_Process2.Id
                Shell(to_kill)
                MsgBox("Closing Application in debugging mode may result in catastrophic errors.Please ensure safe application shutdown", MsgBoxStyle.Information)

            End If

        Catch ex As Exception

        End Try



        If file_saved = False Then
            If MsgBox(" file is not saved: u may recover it later", MsgBoxStyle.Information) = MsgBoxResult.Ok Then
            Else
                End
            End If

        End If
    End Sub


    Private Sub Form5_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer1.Start()






    End Sub

    Private Sub DashboardToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DashboardToolStripMenuItem.Click
        Form2.ShowDialog()
    End Sub

    Private Sub DashboardToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DashboardToolStripMenuItem1.Click
        Form2.ShowDialog()
    End Sub

    Private Sub DashboardToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DashboardToolStripMenuItem2.Click
        Form2.ShowDialog()
    End Sub

    Private Sub DashboardToolStripMenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DashboardToolStripMenuItem3.Click
        Form2.ShowDialog()
    End Sub

    Private Sub DashboardToolStripMenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DashboardToolStripMenuItem4.Click
        Form2.ShowDialog()
    End Sub



    Private Sub ToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AppLaunchrToolStripButton1.Click
        Try
            Shell(applauncher.Text, AppWinStyle.NormalFocus)
        Catch ex As Exception

        End Try

    End Sub

    Private Sub NewToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewToolStripButton.Click
        editorRichTextBox1.ResetText()

        If t16_bit_turboc_flag = True Then

            editorRichTextBox1.Text = C_CPPtmplte.Text
        ElseIf Jv_bit_flag = True Then
            editorRichTextBox1.Text = TextBox4.Text
        End If
    End Sub

    Private Sub CutToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CutToolStripButton.Click
        editorRichTextBox1.Cut()
    End Sub

    Private Sub CopyToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyToolStripButton.Click
        editorRichTextBox1.Copy()
    End Sub

    Private Sub PasteToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PasteToolStripButton.Click
        editorRichTextBox1.Paste()
    End Sub

    Private Sub ToolStripButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton4.Click
        If editorRichTextBox1.WordWrap = True Then
            editorRichTextBox1.WordWrap = False
        ElseIf editorRichTextBox1.WordWrap = False Then
            editorRichTextBox1.WordWrap = True
        End If
    End Sub


    Private Sub ToolStripTextBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripTextBox1.Click
        FontDialog1.ShowColor = True
        FontDialog1.ShowApply = True
        FontDialog1.ShowEffects = True
        FontDialog1.ShowHelp = True
        FontDialog1.AllowVectorFonts = True
        FontDialog1.ShowDialog()
    End Sub

    Private Sub NumericUpDown1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown1.ValueChanged

        Try
            Dim f As New System.Drawing.Font(editorRichTextBox1.Font.Name, NumericUpDown1.Value)
            editorRichTextBox1.Font = f
        Catch ex As Exception
            MsgBox("The font couldnot be applied", MsgBoxStyle.Information)
        End Try

    End Sub

    Private Sub NewToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewToolStripButton1.Click
        DocWebBrowser1.Navigate(DocLaunchrTextBox2.Text)
    End Sub

    Private Sub DocLaunchrTextBox2_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles DocLaunchrTextBox2.KeyDown
        If e.KeyCode = Keys.Enter Then
            NewToolStripButton1.PerformClick()
        End If
    End Sub


    Private Sub applauncher_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles applauncher.KeyDown
        If e.KeyCode = Keys.Enter Then
            AppLaunchrToolStripButton1.PerformClick()
        End If
    End Sub

    Private Sub ToolStripButton1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton1.Click
        editorRichTextBox1.Undo()
    End Sub

    Private Sub ToolStripButton5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton5.Click
        editorRichTextBox1.Redo()
    End Sub

    Private Sub ToolStripButton6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton6.Click
        editorRichTextBox1.SelectAll()
    End Sub



    Private Sub editorRichTextBox1_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles editorRichTextBox1.KeyUp
        If html_flag = False Then
            If e.KeyCode = Keys.OemSemicolon Then

                If ToolStripLabel7.Text <> " " And ToolStripLabel1.Text <> "filename" Then

                    If t16_bit_turboc_flag = True Then
                        compile_prog_16bit()

                    ElseIf Jv_bit_flag = True Then
                        compile_jv_prog()

                    End If



                Else
                    MsgBox(" please save the file first")

                End If
            End If

        End If

    End Sub

    Private Sub editorRichTextBox1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles editorRichTextBox1.MouseEnter
        Me.Opacity = 1
        Me.Refresh()
    End Sub



    Private Sub editorRichTextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles editorRichTextBox1.TextChanged
        ToolStripLabel10.Text = editorRichTextBox1.Lines.Count
        If editorRichTextBox1.CanUndo = True Then
            ToolStripButton1.Enabled = True
        Else
            ToolStripButton1.Enabled = False
        End If
        If editorRichTextBox1.CanRedo Then
            ToolStripButton5.Enabled = True
        Else
            ToolStripButton5.Enabled = False
        End If


        If html_flag = True Then
            DocWebBrowser1.DocumentText = editorRichTextBox1.Text

        End If

        file_saved = False
        ToolStripLabel6.Text = "unsaved document"
    End Sub

    Private Sub ToolStripButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton2.Click
        If html_flag = True Then
            If SplitContainer1.Orientation = Orientation.Horizontal Then
                SplitContainer1.Orientation = Orientation.Vertical
            Else
                SplitContainer1.Orientation = Orientation.Horizontal
            End If

            SplitContainer1.Panel1Collapsed = True
        Else
            If SplitContainer1.Panel2Collapsed = True Then
                SplitContainer1.Panel2Collapsed = False
            ElseIf SplitContainer1.Panel2Collapsed = False Then
                SplitContainer1.Panel2Collapsed = True
            End If
        End If


    End Sub



    Private Sub CompileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CompileToolStripMenuItem.Click
        SplitContainer1.Panel2Collapsed = True
        Try
            If file_saved = False Then
                editorRichTextBox1.SaveFile(fname, RichTextBoxStreamType.PlainText)
            End If

            editorRichTextBox1.ReadOnly = True
        Catch ex As Exception

        End Try

        Try
            compile_prog_16bit()
            runtime_form.ShowDialog()

        Catch ex As Exception

        End Try




        editorRichTextBox1.ReadOnly = False
    End Sub


    Private Sub SaveToolStripMenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem4.Click
        Try
            If ToolStripLabel7.Text = " " Then
                MsgBox("please select file type")
                Panel1.BackColor = Color.DarkRed
                Panel1.ForeColor = Color.White

            End If
            Me.Cursor = Cursors.WaitCursor
            ToolStripLabel6.Text = "saving...."
            last_saved = Now.ToString
            fname = ToolStripTextBox2.Text & ToolStripLabel7.Text
            REM  MsgBox(fname)
            If My.Computer.FileSystem.FileExists(fname) = True Then
                If MsgBox("a file named " & fname & "already exists in the specified location, do u want to overwrite?", MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
                    editorRichTextBox1.SaveFile(fname, RichTextBoxStreamType.PlainText)
                    Me.Cursor = Cursors.Arrow
                    ToolStripLabel6.Text = "file saved:"
                    ToolStripLabel1.Text = ToolStripTextBox2.Text
                    Me.Text = "bytespace beta 1.0 - " & fname & "-last saved @ " & last_saved
                    CompileToolStripMenuItem.Enabled = True
                Else
                    Me.Cursor = Cursors.Arrow
                End If

            Else
                editorRichTextBox1.SaveFile(fname, RichTextBoxStreamType.PlainText)
                Me.Cursor = Cursors.Arrow
                ToolStripLabel6.Text = "file saved:"
                ToolStripLabel1.Text = ToolStripTextBox2.Text
                Me.Text = "bytespace beta 1.0 - " & fname & "-last saved @ " & last_saved
                CompileToolStripMenuItem.Enabled = True
            End If

            file_saved = True

        Catch ex As Exception
            MsgBox("exception:file could not be saved", MsgBoxStyle.Information)
            ToolStripLabel6.Text = "file could not be saved:"
        End Try

    End Sub



    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        Label3.Visible = False
        Label4.Visible = False


        If t16_bit_turboc_flag = True Then
            If TextBox1.Text.Contains("Error") Then
                TextBox1.ForeColor = Color.Red
                executeToolStripMenuItem1.Enabled = False
                Label3.Visible = True
                Me.BackColor = Color.Red
            ElseIf TextBox1.Text.Contains("Warning") Then
                TextBox1.ForeColor = Color.SeaGreen
                executeToolStripMenuItem1.Enabled = True
                Label4.Visible = True
                Me.BackColor = Color.Green
            Else
                Me.BackColor = Color.Navy
                TextBox1.ForeColor = Color.MidnightBlue
                executeToolStripMenuItem1.Enabled = True
            End If

        ElseIf Jv_bit_flag = True Then
            If TextBox1.Text.Contains("error") Or TextBox1.Text.Contains("reached end of file") Or TextBox1.Text.Contains("expected") Then
                TextBox1.ForeColor = Color.Red
                executeToolStripMenuItem1.Enabled = False
                Label3.Visible = True
                Me.BackColor = Color.Red
            Else
                Me.BackColor = Color.Navy
                TextBox1.ForeColor = Color.MidnightBlue
                executeJv_ToolStripMenuItem2.Enabled = True
            End If
        End If

    End Sub




    Private Sub RadioButton3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton3.CheckedChanged
        If RadioButton3.Checked = True Then
            ToolStripLabel7.Text = ".java"
        End If
    End Sub

    Private Sub RadioButton4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton4.CheckedChanged
        If RadioButton4.Checked = True Then
            ToolStripLabel7.Text = ".txt"
        End If
    End Sub

    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked = True Then
            ToolStripLabel7.Text = ".c"
        End If
    End Sub

    Private Sub RadioButton2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton2.CheckedChanged
        If RadioButton2.Checked = True Then
            ToolStripLabel7.Text = ".cpp"
        End If
    End Sub


    Private Sub ToolStripLabel7_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ToolStripLabel7.TextChanged
        Panel1.BackColor = Color.White
        Panel1.ForeColor = Color.Navy
    End Sub

    Private Sub ToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles executeToolStripMenuItem1.Click
        stck_trce = Environment.StackTrace
        REM    execute processs
        compile_prog_16bit()

        Dim arg As String
        arg = ToolStripTextBox7.Text
        editorRichTextBox1.ReadOnly = True
        Dim path As String
        path = ToolStripTextBox2.Text & ".exe"
        REM MsgBox(path)
        runtime_form.Button3.Text = "load"

        Try

            execute_TC_Process2.StartInfo.FileName = "cmd"
            execute_TC_Process2.StartInfo.Arguments = "/C title bytespace build 1.0 &" & path & " " & arg & "  & pause "
            execute_TC_Process2.StartInfo.UseShellExecute = True
            execute_TC_Process2.StartInfo.WindowStyle = ProcessWindowStyle.Normal

            REM execute_Process2.StartInfo.Arguments = "/C " & path
            execute_TC_Process2.Start()


        Catch ex As Exception

        End Try
        stck_trce = Environment.StackTrace
        editorRichTextBox1.ReadOnly = False

    End Sub

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenToolStripMenuItem.Click
        OpenToolStripButton.PerformClick()
    End Sub

    Private Sub NewToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewToolStripMenuItem.Click
        editorRichTextBox1.Text = C_CPPtmplte.Text
    End Sub



    Private Sub ToolStripLabel10_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ToolStripLabel10.TextChanged


        If ToolStripLabel10.Text > 9 Then
            If html_flag = False Then


                If ToolStripLabel7.Text <> " " And ToolStripLabel1.Text <> "filename" Then

                    If t16_bit_turboc_flag = True Then
                        compile_prog_16bit()

                    ElseIf Jv_bit_flag = True Then
                        compile_jv_prog()

                    End If

                Else
                    MsgBox(" please save the file first")

                End If


            End If
        End If

        If ToolStripLabel10.Text > 5 Then
            editorRichTextBox1.ScrollBars = RichTextBoxScrollBars.ForcedBoth
        End If
    End Sub





    Private Sub ToolStripLabel6_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ToolStripLabel6.TextChanged
        If html_flag = True Then
            ToolStripTextBox6.BackColor = Color.MediumPurple
            SaveToolStripMenuItem.BackColor = Color.Transparent
            SaveToolStripMenuItem.ForeColor = Color.Black
        End If
       
    End Sub


    Private Sub SaveToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripButton1.Click
        DocWebBrowser1.ShowSaveAsDialog()
    End Sub

    Private Sub PrintToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintToolStripButton1.Click
        DocWebBrowser1.ShowPrintDialog()
    End Sub


    Private Sub PrintOptionsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintOptionsToolStripMenuItem.Click
        Dim print_text As String
        If html_flag = True Then
            DocWebBrowser1.ShowPrintDialog()
        Else
            ide_engine_WebBrowser1.Navigate(CurDir)
            print_text = "<html><head><title>" & ToolStripTextBox2.Text & ToolStripLabel7.Text & "</title></head>" & "<body>" & editorRichTextBox1.Text & "</body></html>"
            ide_engine_WebBrowser1.DocumentText = print_text

            ide_engine_WebBrowser1.ShowPrintDialog()
        End If


    End Sub

    Private Sub PrintPreviewToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintPreviewToolStripMenuItem.Click
        If html_flag = True Then
            DocWebBrowser1.ShowPrintPreviewDialog()
        Else
            ide_engine_WebBrowser1.DocumentText = editorRichTextBox1.Text
            ide_engine_WebBrowser1.ShowPrintPreviewDialog()
        End If

    End Sub

    Private Sub PrintToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintToolStripMenuItem.Click
        If html_flag = True Then
            DocWebBrowser1.Print()
        Else
            ide_engine_WebBrowser1.Print()
        End If

    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveAsToolStripMenuItem.Click
        If html_flag = True Then
            DocWebBrowser1.ShowSaveAsDialog()
        Else
        
            SaveFileDialog1.Filter = "txt files (*.txt)|*.txt|c files (*.c)|*.c| c++ files (*.cpp)|*.cpp|All files (*.*)|*.*"
            SaveFileDialog1.FilterIndex = 2
            SaveFileDialog1.RestoreDirectory = True
            If (SaveFileDialog1.ShowDialog() = DialogResult.OK) Then
                editorRichTextBox1.SaveFile(SaveFileDialog1.FileName, RichTextBoxStreamType.PlainText)

            End If


        End If

    End Sub

    Private Sub SaveToolStripMenuItem10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem10.Click
        If t16_bit_turboc_flag = True Then
            SaveToolStripMenuItem4.PerformClick()

        ElseIf Jv_bit_flag = True Then

            SaveToolStripMenuItem3.PerformClick()

        ElseIf html_flag = True Then
            REM  SaveToolStripButton1.PerformClick() :causes runtime error.
        End If
    End Sub

    Private Sub Form5_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown


        ide_create()




    End Sub


    Private Sub PrintToolStripButton_ButtonClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintToolStripButton.ButtonClick
        If html_flag = True Then
            PrintToolStripButton1.PerformClick()
        End If

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Try

            editorRichTextBox1.SaveFile(fname, RichTextBoxStreamType.PlainText)
            last_saved = Now.ToString
            Me.Text = "bytespace beta 1.0 - " & fname & "-last auto saved @ " & last_saved
        Catch ex As Exception

        End Try
    End Sub


    Private Sub SaveToolStripButton_ButtonClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripButton.ButtonClick
        SaveToolStripMenuItem10.PerformClick()
    End Sub

    Private Sub ToolStripLabel10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripLabel10.Click

    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem.Click
        Dim path As String
        path = CurDir() & "\" & fname
        My.Computer.Network.DownloadFile(fname, path)
        ToolStripLabel6.Visible = False
    End Sub

    Private Sub MenuStrip5_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles MenuStrip5.ItemClicked

    End Sub

    Private Sub ToolStrip1_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ToolStrip1.ItemClicked

    End Sub

    Private Sub OpenToolStripButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles OpenToolStripButton.Click

        OpenFileDialog1.DefaultExt = "txt"
        OpenFileDialog1.FileName = " "
        If html_flag = True Then
            OpenFileDialog1.Filter = _
               "htm files (*.htm)|*.htm| mht files (*.mht)|*.mht|html files (*.html)|*.html|txt files (*.txt)|*.txt|All files (*.*)|*.*"

        End If
        If t16_bit_turboc_flag = True Then
            OpenFileDialog1.Filter = _
            "c files (*.c)|*.c| c++ files (*.cpp)|*.cpp|txt files (*.txt)|*.txt|All files (*.*)|*.*"

        End If
        If Jv_bit_flag = True Then
            OpenFileDialog1.Filter = _
           "java files (*.java)|*.java|txt files (*.txt)|*.txt|All files (*.*)|*.*"
            RadioButton3.Select()

        End If
       
        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then

            editorRichTextBox1.LoadFile(OpenFileDialog1.FileName, RichTextBoxStreamType.PlainText)
            If html_flag = True Then
                DocWebBrowser1.Navigate(OpenFileDialog1.FileName)
                ToolStripButton2.PerformClick()
                TabControl1.DeselectTab(0)
                TabPage1.Text = "help"
            End If

        End If
    End Sub

    Private Sub ToolStripLabel7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripLabel7.Click

    End Sub

    Private Sub SaveToolStripMenuItem5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem5.Click
        SaveToolStripButton.PerformClick()
    End Sub

    Private Sub NewToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewToolStripMenuItem1.Click
        NewToolStripButton.PerformClick()
    End Sub

    Private Sub SaveToolStripMenuItem6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem6.Click
        SaveToolStripMenuItem3.PerformClick()
    End Sub

    Private Sub OpenToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenToolStripMenuItem1.Click
        register.ShowDialog()
    End Sub

    Private Sub NewToolStripMenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewToolStripMenuItem4.Click
        NewToolStripButton.PerformClick()
    End Sub

    Private Sub SaveToolStripMenuItem9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem9.Click
        SaveToolStripButton.PerformClick()
    End Sub

    Private Sub ToolStripMenuItem69_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem69.Click
        Me.Close()
    End Sub

    Private Sub ExitToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem1.Click
        Me.Close()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub SaveToolStripMenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem3.Click
        Try
            If ToolStripLabel7.Text = " " Then
                MsgBox("please select file type")
                Panel1.BackColor = Color.DarkRed
                Panel1.ForeColor = Color.White
                Exit Sub
            End If
            Me.Cursor = Cursors.WaitCursor
            ToolStripLabel6.Text = "saving...."
            last_saved = Now.ToString
            fname = ToolStripTextBox3.Text & ToolStripLabel7.Text
            REM  MsgBox(fname)
            If My.Computer.FileSystem.FileExists(fname) = True Then
                If MsgBox("a file named " & fname & " already exists in the specified location, do u want to overwrite?", MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
                    editorRichTextBox1.SaveFile(fname, RichTextBoxStreamType.PlainText)
                    Me.Cursor = Cursors.Arrow
                    ToolStripLabel6.Text = "file saved:"
                End If
            Else
                editorRichTextBox1.SaveFile(fname, RichTextBoxStreamType.PlainText)
                Me.Cursor = Cursors.Arrow
                ToolStripLabel6.Text = "file saved:"
            End If


            ToolStripLabel1.Text = ToolStripTextBox3.Text
            Me.Text = "bytespace beta 1.0 - " & fname & "-last saved @ " & last_saved
            CompileToolStripMenuItem1.Enabled = True
            file_saved = True

        Catch ex As Exception
            MsgBox("exception:file could not be saved", MsgBoxStyle.Information)
            ToolStripLabel6.Text = "file could not be saved:"
        End Try
    End Sub

    Private Sub CompileToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CompileToolStripMenuItem1.Click
        SplitContainer1.Panel2Collapsed = True
        Try
            If file_saved = False Then
                editorRichTextBox1.SaveFile(fname, RichTextBoxStreamType.PlainText)
            End If

            editorRichTextBox1.ReadOnly = True
        Catch ex As Exception

        End Try

        Try
            If compile_jv_prog() = 0 Then
                runtime_form.ShowDialog()
            End If

        Catch ex As Exception

        End Try




        editorRichTextBox1.ReadOnly = False
    End Sub

    Private Sub ToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles executeJv_ToolStripMenuItem2.Click
        REM    execute processs

        compile_jv_prog()
        stck_trce = Environment.StackTrace
        Dim arg As String
        arg = ToolStripTextBox8.Text
        editorRichTextBox1.ReadOnly = True
        Dim path As String
        path = Trim(ToolStripTextBox3.Text)
        REM MsgBox(path)
        runtime_form.Button3.Text = "load"

        Try

            execute_JV_Process2.StartInfo.FileName = "cmd"
            execute_JV_Process2.StartInfo.Arguments = "/C title bytespace build 1.0 & java " & path & " " & arg & " & pause"
            execute_JV_Process2.StartInfo.UseShellExecute = True
            execute_JV_Process2.StartInfo.WindowStyle = ProcessWindowStyle.Normal

            REM execute_Process2.StartInfo.Arguments = "/C " & path
            execute_JV_Process2.Start()


        Catch ex As Exception

        End Try
        stck_trce = Environment.StackTrace
        editorRichTextBox1.ReadOnly = False

    End Sub



    Private Sub BackgroundWorker1_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork

    End Sub

    Private Sub backToolStripButton3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles backToolStripButton3.Click
        DocWebBrowser1.GoBack()
    End Sub

    Private Sub fwdToolStripButton7_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles fwdToolStripButton7.Click
        DocWebBrowser1.GoForward()
    End Sub

    Private Sub stopToolStripButton8_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles stopToolStripButton8.Click
        DocWebBrowser1.Stop()
    End Sub

    Private Sub refreshToolStripButton9_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles refreshToolStripButton9.Click
        DocWebBrowser1.Refresh()
    End Sub

    

    Private Sub DocWebBrowser1_Navigated(ByVal sender As Object, ByVal e As System.Windows.Forms.WebBrowserNavigatedEventArgs) Handles DocWebBrowser1.Navigated
        If DocWebBrowser1.CanGoBack = False Then
            backToolStripButton3.Enabled = False
        End If
        If DocWebBrowser1.CanGoForward = False Then
            fwdToolStripButton7.Enabled = False
        End If
        stopToolStripButton8.Enabled = False
        refreshToolStripButton9.Enabled = True
    End Sub

    Private Sub DocWebBrowser1_Navigating(ByVal sender As Object, ByVal e As System.Windows.Forms.WebBrowserNavigatingEventArgs) Handles DocWebBrowser1.Navigating
        stopToolStripButton8.Enabled = True
    End Sub

    Private Sub CodeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CodeToolStripMenuItem.Click
        SplitContainer1.Panel1Collapsed = False
    End Sub

    Private Sub SaveToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem1.Click

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

    End Sub

    Private Sub DocWebBrowser1_DocumentCompleted(ByVal sender As System.Object, ByVal e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles DocWebBrowser1.DocumentCompleted

        Try
            ToolStripTextBox6.Text = DocWebBrowser1.Site.Name
        Catch ex As Exception

        End Try

    End Sub

    Private Sub ToolStripLabel6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripLabel6.Click

    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        If file_saved = True Then
            Panel1.Visible = False

        End If
    End Sub

  
    Private Sub BackgroundWorker1_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorker1.RunWorkerCompleted

    End Sub
End Class