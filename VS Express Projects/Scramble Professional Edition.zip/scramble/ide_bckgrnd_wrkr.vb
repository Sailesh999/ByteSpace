﻿Module ide_bckgrnd_wrkr

    Function compile_prog_16bit() As Integer
        Dim path As String
        path = My.Computer.FileSystem.CurrentDirectory
        Form5.compile_TC_Process1.StartInfo.WorkingDirectory = path


        Form5.compile_TC_Process1.StartInfo.FileName = "cmd"
        Form5.compile_TC_Process1.StartInfo.Arguments = "/C tcc " & Form5.fname
        
        Form5.compile_TC_Process1.StartInfo.CreateNoWindow = True
        Form5.compile_TC_Process1.StartInfo.UseShellExecute = False
        Form5.compile_TC_Process1.StartInfo.RedirectStandardOutput = True
        Try
        Form5.editorRichTextBox1.SaveFile(Form5.fname, RichTextBoxStreamType.PlainText)
        Try
            Form5.compile_TC_Process1.Start()

            Form5.compile_TC_Process1.WaitForExit()
                Form5.stck_trce = Environment.StackTrace
            runtime_form.TextBox2.Visible = True
            If Form5.compile_TC_Process1.HasExited = True Then
                runtime_form.Label2.Text = "file successfully compiled"
                runtime_form.PictureBox1.Visible = False
            End If

            runtime_form.TextBox2.Text = Form5.compile_TC_Process1.StandardOutput.ReadToEnd()
            Form5.TextBox1.Text = Form5.outpt_tmplte_TextBox2.Text & vbNewLine & runtime_form.TextBox2.Text


            runtime_form.TextBox2.ScrollBars = ScrollBars.Vertical
        Catch ex As Exception
            MsgBox("exception: file could not be compiled", MsgBoxStyle.Critical)
            End Try
        Catch ex1 As Exception
            MsgBox("invalid file name ")
        End Try
        Return 0
    End Function




    Function ide_create() As Integer

        Form5.t16_bit_turboc_flag = False
        Form5.Jv_bit_flag = False
        Form5.avrc_flag = False
        Form5.avrgcc_flag = False
        Form5.html_flag = False
        Form5.SplitContainer1.Panel1Collapsed = False
        Form5.SplitContainer1.Orientation = Orientation.Horizontal
        Form5.TabPage1.Text = "output"
        Form5.TabControl1.DeselectTab(1)
        If Form5.language_index = 1 Then          REM C / C++ 16 bit turbo
            Form5.MenuStrip1.Visible = True
            Form5.MenuStrip2.Visible = False
            Form5.MenuStrip3.Visible = False
            Form5.MenuStrip5.Visible = False
            Form5.MenuStrip4.Visible = False
            Form5.Panel1.Visible = True
            Form5.ToolStripLabel8.Text = Form5.TextBox2.Text
            Form5.t16_bit_turboc_flag = True
        End If
        If Form5.language_index = 2 Then          REM Oracle-Sun Java
            Form5.MenuStrip2.Visible = True
            Form5.MenuStrip1.Visible = False
            Form5.MenuStrip3.Visible = False
            Form5.MenuStrip5.Visible = False
            Form5.MenuStrip4.Visible = False
            Form5.Panel1.Visible = True
            Form5.Jv_bit_flag = True
        End If
        If Form5.language_index = 3 Then          REM C / C++ AVR C/C++
            Form5.MenuStrip3.Visible = True
            Form5.MenuStrip2.Visible = False
            Form5.MenuStrip1.Visible = False
            Form5.MenuStrip5.Visible = False
            Form5.MenuStrip4.Visible = False
            Form5.Panel1.Visible = True
            Form5.avrc_flag = True
        End If
        If Form5.language_index = 4 Then          REM C / C++ AVR GCC
            Form5.MenuStrip4.Visible = True
            Form5.MenuStrip2.Visible = False
            Form5.MenuStrip3.Visible = False
            Form5.MenuStrip1.Visible = False
            Form5.MenuStrip5.Visible = False
            Form5.Panel1.Visible = True
            Form5.avrgcc_flag = True
        End If
        If Form5.language_index = 5 Then          REM HTML / Jscript / VB script
            Form5.MenuStrip5.Visible = True
            Form5.MenuStrip2.Visible = False
            Form5.MenuStrip3.Visible = False
            Form5.MenuStrip4.Visible = False
            Form5.MenuStrip1.Visible = False
            Form5.Panel1.Visible = False
            Form5.html_flag = True
            Form5.TabPage2.BringToFront()

            Form5.TabControl1.DeselectTab(0)
            Form5.TabPage1.Text = "help"
        End If
        Form5.TextBox1.Text = ""
        Form5.SplitContainer2.Panel1Collapsed = True
        Form5.ToolStripTextBox1.Text = Form5.editorRichTextBox1.Font.Name
        Form5.NumericUpDown1.Value = Form5.editorRichTextBox1.Font.SizeInPoints
        Return 0
    End Function


    Function find_lang_index() As Integer

        If Form5.language_index = 1 Then
            Form2.Button6.Text = "C / C++ 16 bit turbo"
        ElseIf Form5.language_index = 2 Then
            Form2.Button6.Text = "Oracle-Sun Java"
        ElseIf Form5.language_index = 3 Then
            Form2.Button6.Text = "C / C++ AVR C/C++"
        ElseIf Form5.language_index = 4 Then
            Form2.Button6.Text = "C / C++ AVR GCC"
        ElseIf Form5.language_index = 5 Then
            Form2.Button6.Text = "HTML / Jscript / VB script"
        End If

        Return 0

    End Function


    Function compile_jv_prog() As Integer
        Dim path As String
        path = My.Computer.FileSystem.CurrentDirectory
        Form5.Compile_JV_Process1.StartInfo.WorkingDirectory = path


        Form5.Compile_JV_Process1.StartInfo.FileName = "cmd"
        Form5.Compile_JV_Process1.StartInfo.Arguments = "/C javac -verbose " & Form5.fname & " & pause"


        Form5.Compile_JV_Process1.StartInfo.CreateNoWindow = True
        Form5.Compile_JV_Process1.StartInfo.UseShellExecute = False
        Form5.Compile_JV_Process1.StartInfo.RedirectStandardOutput = True
        Form5.Compile_JV_Process1.StartInfo.RedirectStandardError = True

        Try

        
        Form5.editorRichTextBox1.SaveFile(Form5.fname, RichTextBoxStreamType.PlainText)
        Try
            Form5.Compile_JV_Process1.Start()
                runtime_form.TextBox2.Text = Form5.Compile_JV_Process1.StandardError.ReadToEnd()
                Form5.stck_trce = Environment.StackTrace
            runtime_form.TextBox2.Visible = True

            If Form5.Compile_JV_Process1.HasExited = True Then
                runtime_form.Label2.Text = "file successfully compiled"
                runtime_form.PictureBox1.Visible = False
            End If

              Form5.TextBox1.Text = Form5.outpt_tmplte_TextBox2.Text & vbNewLine & runtime_form.TextBox2.Text


            runtime_form.TextBox2.ScrollBars = ScrollBars.Vertical
        Catch ex As Exception
                MsgBox("exception: file could not be compiled", MsgBoxStyle.Critical)
                Return 1
            End Try
        Catch ex1 As Exception
            MsgBox("invalid file name ")
            Return 1
        End Try
        Return 0
    End Function


End Module
