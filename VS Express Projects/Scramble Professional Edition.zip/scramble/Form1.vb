﻿Public Class Form1
    Public language_number As Integer = 0
    Private mouseOffset As Point

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click
        End
    End Sub

    Private Sub Label1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label1.MouseEnter
        Label1.BackColor = Color.Tomato
    End Sub

    Private Sub Label1_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label1.MouseLeave
        Label1.BackColor = Color.Crimson
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Height = 189
        Me.Width = 718
        ChDir(My.Computer.FileSystem.SpecialDirectories.MyDocuments)
    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox2.Text = Label7.Text Then
            If Trim(ComboBox1.Text) <> "" And Trim(ComboBox1.Text) <> "select language" Then
                If CheckBox1.CheckState = CheckState.Checked Then
                    Form2.Opacity = 0
                    Form2.Show()
                    Form2.Button5.PerformClick()
                    Form2.Hide()
                    Form2.Opacity = 1
                    Form2.Close()
                Else
                    Form2.Show()
                End If



                Me.Hide()
            Else
                Label12.Visible = True
                Beep()
                
                ComboBox1.DroppedDown = True
            End If


        Else
            Label11.Visible = True
            TextBox1.ForeColor = Color.Red
            TextBox2.ForeColor = Color.Red
            Beep()

        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = "username"
        TextBox2.Text = "abcd"
        TextBox2.ForeColor = Color.Black
        TextBox1.ForeColor = Color.Indigo
        Label11.Visible = False
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        TextBox1.ForeColor = Color.Indigo
        Label11.Visible = False
    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged
        TextBox2.ForeColor = Color.Black
        Label11.Visible = False
    End Sub

    
   

    Private Sub ComboBox1_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox1.TextChanged
        Label12.Visible = False
    End Sub

    Private Sub Form1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseDown
        mouseOffset = New Point(-e.X, -e.Y)
    End Sub

    Private Sub Form1_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseMove
        If e.Button = Windows.Forms.MouseButtons.Left Then
            Dim mousePos As Point = Control.MousePosition
            mousePos.Offset(mouseOffset.X, mouseOffset.Y)
            Location = mousePos
        End If
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

  
End Class
