﻿Imports System.Runtime.InteropServices
Imports System

Imports System.Text

Imports System.IO


Public Class debug_help
    Private mouseOffset As Point
    Dim s As String
    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click
        Me.Close()
    End Sub

    Private Sub MenuStrip1_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub

    Private Sub MenuStrip1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MenuStrip1.MouseDown
        mouseOffset = New Point(-e.X, -e.Y)
    End Sub

    Private Sub MenuStrip1_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MenuStrip1.MouseMove
        If e.Button = Windows.Forms.MouseButtons.Left Then
            Dim mousePos As Point = Control.MousePosition
            mousePos.Offset(mouseOffset.X, mouseOffset.Y)
            Location = mousePos
        End If
    End Sub


    Private Sub TraceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TraceToolStripMenuItem.Click

    End Sub

    Private Sub TableLayoutPanel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles TableLayoutPanel1.Paint

    End Sub

    Private Sub FileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Form5.t16_bit_turboc_flag = True Then

        End If
    End Sub

    Private Sub debug_help_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Form5.Text = s
    End Sub

    Private Sub debug_help_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown

        TextBox2.Text = Form5.stck_trce
        s = Form5.Text
        Form5.Text &= "---Debug mode"
        Process1.StartInfo.FileName = "cmd"
        Process1.StartInfo.Arguments = "/C wmic baseboard"
        Process1.StartInfo.WorkingDirectory = CurDir()
        Process1.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
        Process1.StartInfo.UseShellExecute = False
        Process1.StartInfo.RedirectStandardOutput = True
        Process1.Start()

        With lvwSystemInformation.Items.Add("ArrangeDirection")
            .SubItems.Add(SystemInformation.ArrangeDirection.ToString())
        End With
        With lvwSystemInformation.Items.Add("ArrangeStartingPosition")
            .SubItems.Add(SystemInformation.ArrangeStartingPosition.ToString())
        End With
        With lvwSystemInformation.Items.Add("BootMode")
            .SubItems.Add(SystemInformation.BootMode.ToString())
        End With
        With lvwSystemInformation.Items.Add("Border3DSize")
            .SubItems.Add(SystemInformation.Border3DSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("BorderSize")
            .SubItems.Add(SystemInformation.BorderSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("CaptionButtonSize")
            .SubItems.Add(SystemInformation.CaptionButtonSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("CaptionHeight")
            .SubItems.Add(SystemInformation.CaptionHeight.ToString())
        End With
        With lvwSystemInformation.Items.Add("ComputerName")
            .SubItems.Add(SystemInformation.ComputerName.ToString())
        End With
        With lvwSystemInformation.Items.Add("CursorSize")
            .SubItems.Add(SystemInformation.CursorSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("DbcsEnabled")
            .SubItems.Add(SystemInformation.DbcsEnabled.ToString())
        End With
        With lvwSystemInformation.Items.Add("DebugOS")
            .SubItems.Add(SystemInformation.DebugOS.ToString())
        End With
        With lvwSystemInformation.Items.Add("DoubleClickSize")
            .SubItems.Add(SystemInformation.DoubleClickSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("DoubleClickTime")
            .SubItems.Add(SystemInformation.DoubleClickTime.ToString())
        End With
        With lvwSystemInformation.Items.Add("DragFullWindows")
            .SubItems.Add(SystemInformation.DragFullWindows.ToString())
        End With
        With lvwSystemInformation.Items.Add("DragSize")
            .SubItems.Add(SystemInformation.DragSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("FixedFrameBorderSize")
            .SubItems.Add(SystemInformation.FixedFrameBorderSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("FrameBorderSize")
            .SubItems.Add(SystemInformation.FrameBorderSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("HighContrast")
            .SubItems.Add(SystemInformation.HighContrast.ToString())
        End With
        With lvwSystemInformation.Items.Add("HorizontalScrollBarArrowWidth")
            .SubItems.Add(SystemInformation.HorizontalScrollBarArrowWidth.ToString())
        End With
        With lvwSystemInformation.Items.Add("HorizontalScrollBarHeight")
            .SubItems.Add(SystemInformation.HorizontalScrollBarHeight.ToString())
        End With
        With lvwSystemInformation.Items.Add("HorizontalScrollBarThumbWidth")
            .SubItems.Add(SystemInformation.HorizontalScrollBarThumbWidth.ToString())
        End With
        With lvwSystemInformation.Items.Add("IconSize")
            .SubItems.Add(SystemInformation.IconSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("IconSpacingSize")
            .SubItems.Add(SystemInformation.IconSpacingSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("KanjiWindowHeight")
            .SubItems.Add(SystemInformation.KanjiWindowHeight.ToString())
        End With
        With lvwSystemInformation.Items.Add("MaxWindowTrackSize")
            .SubItems.Add(SystemInformation.MaxWindowTrackSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("MenuButtonSize")
            .SubItems.Add(SystemInformation.MenuButtonSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("MenuCheckSize")
            .SubItems.Add(SystemInformation.MenuCheckSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("MenuFont")
            .SubItems.Add(SystemInformation.MenuFont.ToString())
        End With
        With lvwSystemInformation.Items.Add("MenuHeight")
            .SubItems.Add(SystemInformation.MenuHeight.ToString())
        End With
        With lvwSystemInformation.Items.Add("MidEastEnabled")
            .SubItems.Add(SystemInformation.MidEastEnabled.ToString())
        End With
        With lvwSystemInformation.Items.Add("MinimizedWindowSize")
            .SubItems.Add(SystemInformation.MinimizedWindowSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("MinimizedWindowSpacingSize")
            .SubItems.Add(SystemInformation.MinimizedWindowSpacingSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("MinimumWindowSize")
            .SubItems.Add(SystemInformation.MinimumWindowSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("MinWindowTrackSize")
            .SubItems.Add(SystemInformation.MinWindowTrackSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("MonitorCount")
            .SubItems.Add(SystemInformation.MonitorCount.ToString())
        End With
        With lvwSystemInformation.Items.Add("MonitorsSameDisplayFormat")
            .SubItems.Add(SystemInformation.MonitorsSameDisplayFormat.ToString())
        End With
        With lvwSystemInformation.Items.Add("MouseButtons")
            .SubItems.Add(SystemInformation.MouseButtons.ToString())
        End With
        With lvwSystemInformation.Items.Add("MouseButtonsSwapped")
            .SubItems.Add(SystemInformation.MouseButtonsSwapped.ToString())
        End With
        With lvwSystemInformation.Items.Add("MousePresent")
            .SubItems.Add(SystemInformation.MousePresent.ToString())
        End With
        With lvwSystemInformation.Items.Add("MouseWheelPresent")
            .SubItems.Add(SystemInformation.MouseWheelPresent.ToString())
        End With
        With lvwSystemInformation.Items.Add("MouseWheelScrollLines")
            .SubItems.Add(SystemInformation.MouseWheelScrollLines.ToString())
        End With
        With lvwSystemInformation.Items.Add("NativeMouseWheelSupport")
            .SubItems.Add(SystemInformation.NativeMouseWheelSupport.ToString())
        End With
        With lvwSystemInformation.Items.Add("Network")
            .SubItems.Add(SystemInformation.Network.ToString())
        End With
        With lvwSystemInformation.Items.Add("PenWindows")
            .SubItems.Add(SystemInformation.PenWindows.ToString())
        End With
        With lvwSystemInformation.Items.Add("PrimaryMonitorMaximizedWindowSize")
            .SubItems.Add(SystemInformation.PrimaryMonitorMaximizedWindowSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("PrimaryMonitorSize")
            .SubItems.Add(SystemInformation.PrimaryMonitorSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("RightAlignedMenus")
            .SubItems.Add(SystemInformation.RightAlignedMenus.ToString())
        End With
        With lvwSystemInformation.Items.Add("Secure")
            .SubItems.Add(SystemInformation.Secure.ToString())
        End With
        With lvwSystemInformation.Items.Add("ShowSounds")
            .SubItems.Add(SystemInformation.ShowSounds.ToString())
        End With
        With lvwSystemInformation.Items.Add("SmallIconSize")
            .SubItems.Add(SystemInformation.SmallIconSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("ToolWindowCaptionButtonSize")
            .SubItems.Add(SystemInformation.ToolWindowCaptionButtonSize.ToString())
        End With
        With lvwSystemInformation.Items.Add("ToolWindowCaptionHeight")
            .SubItems.Add(SystemInformation.ToolWindowCaptionHeight.ToString())
        End With
        With lvwSystemInformation.Items.Add("UserDomainName")
            .SubItems.Add(SystemInformation.UserDomainName.ToString())
        End With
        With lvwSystemInformation.Items.Add("UserInteractive")
            .SubItems.Add(SystemInformation.UserInteractive.ToString())
        End With
        With lvwSystemInformation.Items.Add("UserName")
            .SubItems.Add(SystemInformation.UserName.ToString())
        End With
        With lvwSystemInformation.Items.Add("VerticalScrollBarArrowHeight")
            .SubItems.Add(SystemInformation.VerticalScrollBarArrowHeight.ToString())
        End With
        With lvwSystemInformation.Items.Add("VerticalScrollBarThumbHeight")
            .SubItems.Add(SystemInformation.VerticalScrollBarThumbHeight.ToString())
        End With
        With lvwSystemInformation.Items.Add("VerticalScrollBarWidth")
            .SubItems.Add(SystemInformation.VerticalScrollBarWidth.ToString())
        End With
        With lvwSystemInformation.Items.Add("VirtualScreen")
            .SubItems.Add(SystemInformation.VirtualScreen.ToString())
        End With
        With lvwSystemInformation.Items.Add("WorkingArea")
            .SubItems.Add(SystemInformation.WorkingArea.ToString())
        End With


        TabPage3.Text = Form5.fname
        SplitContainer1.Panel1Collapsed = True
    End Sub

    Private Sub TestToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TestToolStripMenuItem.Click
       

    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged

    End Sub
End Class