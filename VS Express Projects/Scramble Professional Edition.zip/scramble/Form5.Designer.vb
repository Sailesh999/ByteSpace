﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form5))
        Me.ToolStripContainer1 = New System.Windows.Forms.ToolStripContainer()
        Me.ToolStrip3 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripLabel6 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripLabel7 = New System.Windows.Forms.ToolStripLabel()
        Me.applauncher = New System.Windows.Forms.ToolStripTextBox()
        Me.AppLaunchrToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripLabel2 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripLabel3 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripLabel4 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripLabel5 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripLabel9 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripLabel10 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripLabel8 = New System.Windows.Forms.ToolStripLabel()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.ide_engine_WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.outpt_tmplte_TextBox2 = New System.Windows.Forms.TextBox()
        Me.C_CPPtmplte = New System.Windows.Forms.TextBox()
        Me.HtmlTemplte = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.editorRichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.HelpToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.NewToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.OpenToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.SaveToolStripButton = New System.Windows.Forms.ToolStripSplitButton()
        Me.SaveToolStripMenuItem10 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveAsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintToolStripButton = New System.Windows.Forms.ToolStripSplitButton()
        Me.PrintOptionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintPreviewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator30 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButton4 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton5 = New System.Windows.Forms.ToolStripButton()
        Me.CutToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.CopyToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.PasteToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton6 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator31 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripTextBox1 = New System.Windows.Forms.ToolStripTextBox()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.DocWebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.DocLaunchrTextBox2 = New System.Windows.Forms.TextBox()
        Me.ToolStrip2 = New System.Windows.Forms.ToolStrip()
        Me.NewToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator32 = New System.Windows.Forms.ToolStripSeparator()
        Me.SaveToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.PrintToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.backToolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.fwdToolStripButton7 = New System.Windows.Forms.ToolStripButton()
        Me.stopToolStripButton8 = New System.Windows.Forms.ToolStripButton()
        Me.refreshToolStripButton9 = New System.Windows.Forms.ToolStripButton()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripTextBox2 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripTextBox7 = New System.Windows.Forms.ToolStripTextBox()
        Me.SaveToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CompileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.executeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DashboardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem19 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripTextBox3 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripTextBox8 = New System.Windows.Forms.ToolStripTextBox()
        Me.SaveToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CompileToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.executeJv_ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DashboardToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip3 = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem42 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripMenuItem43 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem44 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem45 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator17 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripMenuItem46 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripTextBox4 = New System.Windows.Forms.ToolStripTextBox()
        Me.CompileToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MakeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BurnToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DashboardToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip4 = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem88 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripMenuItem89 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem90 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem91 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator29 = New System.Windows.Forms.ToolStripSeparator()
        Me.OptionsToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripComboBox4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EraseChipToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerifyDeviceSignatureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PreventWritingToDeviceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisableOutputToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TerminalModeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerboseModeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PreventVerificationCheckToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FlashToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WriteToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReadToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerifyToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EEPROMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WriteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerifyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FuseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HighToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExtendedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitModeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CalibrationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripMenuItem92 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripTextBox5 = New System.Windows.Forms.ToolStripTextBox()
        Me.BuildToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MakeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BurnToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripComboBox1 = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripComboBox2 = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripComboBox3 = New System.Windows.Forms.ToolStripComboBox()
        Me.DashboardToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip5 = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem65 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem9 = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripMenuItem69 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripTextBox6 = New System.Windows.Forms.ToolStripTextBox()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DashboardToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CodeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FontDialog1 = New System.Windows.Forms.FontDialog()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.PrintForm1 = New Microsoft.VisualBasic.PowerPacks.Printing.PrintForm(Me.components)
        Me.compile_TC_Process1 = New System.Diagnostics.Process()
        Me.PrintDialog1 = New System.Windows.Forms.PrintDialog()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.execute_TC_Process2 = New System.Diagnostics.Process()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.Compile_JV_Process1 = New System.Diagnostics.Process()
        Me.execute_JV_Process2 = New System.Diagnostics.Process()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker2 = New System.ComponentModel.BackgroundWorker()
        Me.ToolStripContainer1.BottomToolStripPanel.SuspendLayout()
        Me.ToolStripContainer1.ContentPanel.SuspendLayout()
        Me.ToolStripContainer1.TopToolStripPanel.SuspendLayout()
        Me.ToolStripContainer1.SuspendLayout()
        Me.ToolStrip3.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStrip1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.ToolStrip2.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.MenuStrip2.SuspendLayout()
        Me.MenuStrip3.SuspendLayout()
        Me.MenuStrip4.SuspendLayout()
        Me.MenuStrip5.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStripContainer1
        '
        '
        'ToolStripContainer1.BottomToolStripPanel
        '
        Me.ToolStripContainer1.BottomToolStripPanel.BackColor = System.Drawing.Color.Transparent
        Me.ToolStripContainer1.BottomToolStripPanel.Controls.Add(Me.ToolStrip3)
        '
        'ToolStripContainer1.ContentPanel
        '
        Me.ToolStripContainer1.ContentPanel.Controls.Add(Me.SplitContainer1)
        Me.ToolStripContainer1.ContentPanel.Size = New System.Drawing.Size(958, 399)
        Me.ToolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ToolStripContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStripContainer1.Name = "ToolStripContainer1"
        Me.ToolStripContainer1.Size = New System.Drawing.Size(958, 557)
        Me.ToolStripContainer1.TabIndex = 0
        Me.ToolStripContainer1.Text = "ToolStripContainer1"
        '
        'ToolStripContainer1.TopToolStripPanel
        '
        Me.ToolStripContainer1.TopToolStripPanel.Controls.Add(Me.MenuStrip1)
        Me.ToolStripContainer1.TopToolStripPanel.Controls.Add(Me.MenuStrip3)
        Me.ToolStripContainer1.TopToolStripPanel.Controls.Add(Me.MenuStrip4)
        Me.ToolStripContainer1.TopToolStripPanel.Controls.Add(Me.MenuStrip5)
        Me.ToolStripContainer1.TopToolStripPanel.Controls.Add(Me.MenuStrip2)
        '
        'ToolStrip3
        '
        Me.ToolStrip3.BackColor = System.Drawing.Color.MidnightBlue
        Me.ToolStrip3.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip3.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStrip3.GripMargin = New System.Windows.Forms.Padding(0)
        Me.ToolStrip3.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip3.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripLabel6, Me.ToolStripLabel1, Me.ToolStripLabel7, Me.applauncher, Me.AppLaunchrToolStripButton1, Me.ToolStripLabel2, Me.ToolStripLabel3, Me.ToolStripLabel4, Me.ToolStripLabel5, Me.ToolStripLabel9, Me.ToolStripLabel10, Me.ToolStripLabel8})
        Me.ToolStrip3.Location = New System.Drawing.Point(3, 0)
        Me.ToolStrip3.Name = "ToolStrip3"
        Me.ToolStrip3.Size = New System.Drawing.Size(580, 25)
        Me.ToolStrip3.TabIndex = 1
        '
        'ToolStripLabel6
        '
        Me.ToolStripLabel6.ForeColor = System.Drawing.Color.White
        Me.ToolStripLabel6.Name = "ToolStripLabel6"
        Me.ToolStripLabel6.Size = New System.Drawing.Size(10, 22)
        Me.ToolStripLabel6.Text = " "
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.ForeColor = System.Drawing.Color.AliceBlue
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(51, 22)
        Me.ToolStripLabel1.Text = "filename"
        '
        'ToolStripLabel7
        '
        Me.ToolStripLabel7.ForeColor = System.Drawing.Color.Lavender
        Me.ToolStripLabel7.Name = "ToolStripLabel7"
        Me.ToolStripLabel7.Size = New System.Drawing.Size(10, 22)
        Me.ToolStripLabel7.Text = " "
        '
        'applauncher
        '
        Me.applauncher.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.applauncher.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.RecentlyUsedList
        Me.applauncher.BackColor = System.Drawing.Color.MidnightBlue
        Me.applauncher.ForeColor = System.Drawing.Color.White
        Me.applauncher.Name = "applauncher"
        Me.applauncher.Size = New System.Drawing.Size(300, 25)
        Me.applauncher.Text = "launcher"
        '
        'AppLaunchrToolStripButton1
        '
        Me.AppLaunchrToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.AppLaunchrToolStripButton1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.AppLaunchrToolStripButton1.ForeColor = System.Drawing.Color.Lavender
        Me.AppLaunchrToolStripButton1.Image = CType(resources.GetObject("AppLaunchrToolStripButton1.Image"), System.Drawing.Image)
        Me.AppLaunchrToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.AppLaunchrToolStripButton1.Name = "AppLaunchrToolStripButton1"
        Me.AppLaunchrToolStripButton1.Size = New System.Drawing.Size(23, 22)
        Me.AppLaunchrToolStripButton1.Text = "u"
        Me.AppLaunchrToolStripButton1.ToolTipText = "launch"
        '
        'ToolStripLabel2
        '
        Me.ToolStripLabel2.Name = "ToolStripLabel2"
        Me.ToolStripLabel2.Size = New System.Drawing.Size(10, 22)
        Me.ToolStripLabel2.Text = " "
        '
        'ToolStripLabel3
        '
        Me.ToolStripLabel3.Name = "ToolStripLabel3"
        Me.ToolStripLabel3.Size = New System.Drawing.Size(10, 22)
        Me.ToolStripLabel3.Text = " "
        '
        'ToolStripLabel4
        '
        Me.ToolStripLabel4.Name = "ToolStripLabel4"
        Me.ToolStripLabel4.Size = New System.Drawing.Size(10, 22)
        Me.ToolStripLabel4.Text = " "
        '
        'ToolStripLabel5
        '
        Me.ToolStripLabel5.Name = "ToolStripLabel5"
        Me.ToolStripLabel5.Size = New System.Drawing.Size(10, 22)
        Me.ToolStripLabel5.Text = " "
        '
        'ToolStripLabel9
        '
        Me.ToolStripLabel9.ForeColor = System.Drawing.Color.Lavender
        Me.ToolStripLabel9.Name = "ToolStripLabel9"
        Me.ToolStripLabel9.Size = New System.Drawing.Size(17, 22)
        Me.ToolStripLabel9.Text = "ln"
        '
        'ToolStripLabel10
        '
        Me.ToolStripLabel10.ForeColor = System.Drawing.Color.Lavender
        Me.ToolStripLabel10.Name = "ToolStripLabel10"
        Me.ToolStripLabel10.Size = New System.Drawing.Size(13, 22)
        Me.ToolStripLabel10.Text = "0"
        '
        'ToolStripLabel8
        '
        Me.ToolStripLabel8.BackColor = System.Drawing.Color.LightGreen
        Me.ToolStripLabel8.ForeColor = System.Drawing.Color.LightSkyBlue
        Me.ToolStripLabel8.Name = "ToolStripLabel8"
        Me.ToolStripLabel8.Padding = New System.Windows.Forms.Padding(50, 0, 0, 0)
        Me.ToolStripLabel8.Size = New System.Drawing.Size(111, 22)
        Me.ToolStripLabel8.Text = "help index"
        Me.ToolStripLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.SplitContainer2)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.TabControl1)
        Me.SplitContainer1.Size = New System.Drawing.Size(958, 399)
        Me.SplitContainer1.SplitterDistance = 295
        Me.SplitContainer1.SplitterWidth = 1
        Me.SplitContainer1.TabIndex = 0
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.Button1)
        Me.SplitContainer2.Panel1.Controls.Add(Me.TextBox4)
        Me.SplitContainer2.Panel1.Controls.Add(Me.ide_engine_WebBrowser1)
        Me.SplitContainer2.Panel1.Controls.Add(Me.TextBox3)
        Me.SplitContainer2.Panel1.Controls.Add(Me.TextBox2)
        Me.SplitContainer2.Panel1.Controls.Add(Me.outpt_tmplte_TextBox2)
        Me.SplitContainer2.Panel1.Controls.Add(Me.C_CPPtmplte)
        Me.SplitContainer2.Panel1.Controls.Add(Me.HtmlTemplte)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.Panel1)
        Me.SplitContainer2.Panel2.Controls.Add(Me.NumericUpDown1)
        Me.SplitContainer2.Panel2.Controls.Add(Me.editorRichTextBox1)
        Me.SplitContainer2.Panel2.Controls.Add(Me.ToolStrip1)
        Me.SplitContainer2.Size = New System.Drawing.Size(958, 295)
        Me.SplitContainer2.SplitterDistance = 242
        Me.SplitContainer2.SplitterWidth = 1
        Me.SplitContainer2.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(32, 194)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 7
        Me.Button1.Text = "crawler"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(7, 120)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 22)
        Me.TextBox4.TabIndex = 6
        Me.TextBox4.Text = "public class file_name" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "{" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "public static void main(String[] args)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "{" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "System." & _
            "out.println("" "");" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "// place your code here" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "}" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "}"
        '
        'ide_engine_WebBrowser1
        '
        Me.ide_engine_WebBrowser1.Location = New System.Drawing.Point(209, 8)
        Me.ide_engine_WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.ide_engine_WebBrowser1.Name = "ide_engine_WebBrowser1"
        Me.ide_engine_WebBrowser1.Size = New System.Drawing.Size(128, 78)
        Me.ide_engine_WebBrowser1.TabIndex = 5
        '
        'TextBox3
        '
        Me.TextBox3.ForeColor = System.Drawing.Color.Maroon
        Me.TextBox3.Location = New System.Drawing.Point(4, 92)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 22)
        Me.TextBox3.TabIndex = 4
        Me.TextBox3.Text = "F1 Help   |   F7 Save   |   F8 Build   |   F9 Run" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.TextBox3.Visible = False
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(7, 64)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 22)
        Me.TextBox2.TabIndex = 3
        Me.TextBox2.Text = "F1 Help   |   F7 Save   |   F8 Build   |   F9 Run" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.TextBox2.Visible = False
        '
        'outpt_tmplte_TextBox2
        '
        Me.outpt_tmplte_TextBox2.Location = New System.Drawing.Point(113, 8)
        Me.outpt_tmplte_TextBox2.Name = "outpt_tmplte_TextBox2"
        Me.outpt_tmplte_TextBox2.Size = New System.Drawing.Size(90, 22)
        Me.outpt_tmplte_TextBox2.TabIndex = 2
        Me.outpt_tmplte_TextBox2.Text = "bytespace beta 1.0" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "     copyright (c) december 2010" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "developer:  saileswar kum" & _
            "ar mahakud  " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "------------------------------------------------------------------" & _
            "-----------------------" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'C_CPPtmplte
        '
        Me.C_CPPtmplte.Location = New System.Drawing.Point(7, 36)
        Me.C_CPPtmplte.Name = "C_CPPtmplte"
        Me.C_CPPtmplte.Size = New System.Drawing.Size(100, 22)
        Me.C_CPPtmplte.TabIndex = 1
        Me.C_CPPtmplte.Text = "// #include<.h>" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "int main( char *argc[], char *argv[])" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "{" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "printf("" "");" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "getc" & _
            "h();" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "}" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'HtmlTemplte
        '
        Me.HtmlTemplte.Location = New System.Drawing.Point(7, 8)
        Me.HtmlTemplte.Name = "HtmlTemplte"
        Me.HtmlTemplte.Size = New System.Drawing.Size(100, 22)
        Me.HtmlTemplte.TabIndex = 0
        Me.HtmlTemplte.Text = "<html>" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "<head>" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "</head>" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "<title>" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "</title>" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "<body>" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "</body>" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "</html>"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.RadioButton3)
        Me.Panel1.Controls.Add(Me.RadioButton2)
        Me.Panel1.Controls.Add(Me.RadioButton4)
        Me.Panel1.Controls.Add(Me.RadioButton1)
        Me.Panel1.ForeColor = System.Drawing.Color.Navy
        Me.Panel1.Location = New System.Drawing.Point(518, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(240, 23)
        Me.Panel1.TabIndex = 8
        Me.Panel1.Visible = False
        '
        'RadioButton3
        '
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton3.Location = New System.Drawing.Point(3, 3)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(48, 17)
        Me.RadioButton3.TabIndex = 6
        Me.RadioButton3.Text = ".java"
        Me.RadioButton3.UseVisualStyleBackColor = False
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton2.Location = New System.Drawing.Point(145, 3)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(47, 17)
        Me.RadioButton2.TabIndex = 5
        Me.RadioButton2.Text = ".CPP"
        Me.RadioButton2.UseVisualStyleBackColor = False
        '
        'RadioButton4
        '
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton4.Location = New System.Drawing.Point(57, 3)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(41, 17)
        Me.RadioButton4.TabIndex = 7
        Me.RadioButton4.Text = ".txt"
        Me.RadioButton4.UseVisualStyleBackColor = False
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton1.Location = New System.Drawing.Point(104, 3)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(35, 17)
        Me.RadioButton1.TabIndex = 4
        Me.RadioButton1.Text = ".C"
        Me.RadioButton1.UseVisualStyleBackColor = False
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.Location = New System.Drawing.Point(389, 2)
        Me.NumericUpDown1.Maximum = New Decimal(New Integer() {500, 0, 0, 0})
        Me.NumericUpDown1.Minimum = New Decimal(New Integer() {6, 0, 0, 0})
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(48, 22)
        Me.NumericUpDown1.TabIndex = 3
        Me.NumericUpDown1.Value = New Decimal(New Integer() {6, 0, 0, 0})
        '
        'editorRichTextBox1
        '
        Me.editorRichTextBox1.AcceptsTab = True
        Me.editorRichTextBox1.BackColor = System.Drawing.Color.White
        Me.editorRichTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.editorRichTextBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.editorRichTextBox1.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.editorRichTextBox1.ForeColor = System.Drawing.Color.Black
        Me.editorRichTextBox1.Location = New System.Drawing.Point(0, 30)
        Me.editorRichTextBox1.Name = "editorRichTextBox1"
        Me.editorRichTextBox1.Size = New System.Drawing.Size(715, 265)
        Me.editorRichTextBox1.TabIndex = 2
        Me.editorRichTextBox1.Text = ""
        Me.editorRichTextBox1.WordWrap = False
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackColor = System.Drawing.Color.White
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HelpToolStripButton, Me.NewToolStripButton, Me.ToolStripSeparator8, Me.OpenToolStripButton, Me.SaveToolStripButton, Me.PrintToolStripButton, Me.toolStripSeparator30, Me.ToolStripButton4, Me.ToolStripButton1, Me.ToolStripButton5, Me.CutToolStripButton, Me.CopyToolStripButton, Me.PasteToolStripButton, Me.ToolStripButton6, Me.toolStripSeparator31, Me.ToolStripButton2, Me.ToolStripTextBox1})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Padding = New System.Windows.Forms.Padding(1, 1, 1, 4)
        Me.ToolStrip1.Size = New System.Drawing.Size(715, 30)
        Me.ToolStrip1.TabIndex = 1
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'HelpToolStripButton
        '
        Me.HelpToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.HelpToolStripButton.Image = CType(resources.GetObject("HelpToolStripButton.Image"), System.Drawing.Image)
        Me.HelpToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.HelpToolStripButton.Name = "HelpToolStripButton"
        Me.HelpToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.HelpToolStripButton.Text = "He&lp"
        '
        'NewToolStripButton
        '
        Me.NewToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.NewToolStripButton.Image = CType(resources.GetObject("NewToolStripButton.Image"), System.Drawing.Image)
        Me.NewToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NewToolStripButton.Name = "NewToolStripButton"
        Me.NewToolStripButton.Padding = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.NewToolStripButton.Size = New System.Drawing.Size(24, 22)
        Me.NewToolStripButton.Text = "&New"
        Me.NewToolStripButton.ToolTipText = "Clear"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Padding = New System.Windows.Forms.Padding(3, 0, 3, 0)
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(6, 25)
        '
        'OpenToolStripButton
        '
        Me.OpenToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.OpenToolStripButton.Image = CType(resources.GetObject("OpenToolStripButton.Image"), System.Drawing.Image)
        Me.OpenToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.OpenToolStripButton.Name = "OpenToolStripButton"
        Me.OpenToolStripButton.Padding = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.OpenToolStripButton.Size = New System.Drawing.Size(24, 22)
        Me.OpenToolStripButton.Text = "&Open"
        '
        'SaveToolStripButton
        '
        Me.SaveToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SaveToolStripButton.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SaveToolStripMenuItem10, Me.SaveAsToolStripMenuItem})
        Me.SaveToolStripButton.Image = CType(resources.GetObject("SaveToolStripButton.Image"), System.Drawing.Image)
        Me.SaveToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SaveToolStripButton.Name = "SaveToolStripButton"
        Me.SaveToolStripButton.Padding = New System.Windows.Forms.Padding(3, 0, 3, 0)
        Me.SaveToolStripButton.Size = New System.Drawing.Size(38, 22)
        Me.SaveToolStripButton.Text = "&Save"
        '
        'SaveToolStripMenuItem10
        '
        Me.SaveToolStripMenuItem10.Name = "SaveToolStripMenuItem10"
        Me.SaveToolStripMenuItem10.Size = New System.Drawing.Size(121, 22)
        Me.SaveToolStripMenuItem10.Text = "Save"
        '
        'SaveAsToolStripMenuItem
        '
        Me.SaveAsToolStripMenuItem.Name = "SaveAsToolStripMenuItem"
        Me.SaveAsToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.SaveAsToolStripMenuItem.Text = "Save as..."
        '
        'PrintToolStripButton
        '
        Me.PrintToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PrintToolStripButton.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PrintOptionsToolStripMenuItem, Me.PrintPreviewToolStripMenuItem, Me.PrintToolStripMenuItem})
        Me.PrintToolStripButton.Image = CType(resources.GetObject("PrintToolStripButton.Image"), System.Drawing.Image)
        Me.PrintToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PrintToolStripButton.Name = "PrintToolStripButton"
        Me.PrintToolStripButton.Padding = New System.Windows.Forms.Padding(3, 0, 3, 0)
        Me.PrintToolStripButton.Size = New System.Drawing.Size(38, 22)
        Me.PrintToolStripButton.Text = "&Print"
        '
        'PrintOptionsToolStripMenuItem
        '
        Me.PrintOptionsToolStripMenuItem.Name = "PrintOptionsToolStripMenuItem"
        Me.PrintOptionsToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.PrintOptionsToolStripMenuItem.Text = "Print Options"
        '
        'PrintPreviewToolStripMenuItem
        '
        Me.PrintPreviewToolStripMenuItem.Name = "PrintPreviewToolStripMenuItem"
        Me.PrintPreviewToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.PrintPreviewToolStripMenuItem.Text = "Print Preview"
        '
        'PrintToolStripMenuItem
        '
        Me.PrintToolStripMenuItem.Name = "PrintToolStripMenuItem"
        Me.PrintToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.PrintToolStripMenuItem.Text = "Print"
        '
        'toolStripSeparator30
        '
        Me.toolStripSeparator30.Name = "toolStripSeparator30"
        Me.toolStripSeparator30.Padding = New System.Windows.Forms.Padding(3, 0, 3, 0)
        Me.toolStripSeparator30.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton4
        '
        Me.ToolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.ToolStripButton4.Image = CType(resources.GetObject("ToolStripButton4.Image"), System.Drawing.Image)
        Me.ToolStripButton4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton4.Name = "ToolStripButton4"
        Me.ToolStripButton4.Padding = New System.Windows.Forms.Padding(3, 0, 3, 0)
        Me.ToolStripButton4.Size = New System.Drawing.Size(31, 22)
        Me.ToolStripButton4.Text = "B"
        Me.ToolStripButton4.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ToolStripButton4.ToolTipText = "Toggle Wrap"
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton1.Enabled = False
        Me.ToolStripButton1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.ToolStripButton1.ForeColor = System.Drawing.Color.MidnightBlue
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Padding = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.ToolStripButton1.Size = New System.Drawing.Size(34, 22)
        Me.ToolStripButton1.Text = "M"
        Me.ToolStripButton1.ToolTipText = "undo"
        '
        'ToolStripButton5
        '
        Me.ToolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton5.Enabled = False
        Me.ToolStripButton5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.ToolStripButton5.Image = CType(resources.GetObject("ToolStripButton5.Image"), System.Drawing.Image)
        Me.ToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton5.Name = "ToolStripButton5"
        Me.ToolStripButton5.Padding = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.ToolStripButton5.Size = New System.Drawing.Size(30, 22)
        Me.ToolStripButton5.Text = "L"
        Me.ToolStripButton5.ToolTipText = "redo"
        '
        'CutToolStripButton
        '
        Me.CutToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CutToolStripButton.Image = CType(resources.GetObject("CutToolStripButton.Image"), System.Drawing.Image)
        Me.CutToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CutToolStripButton.Name = "CutToolStripButton"
        Me.CutToolStripButton.Padding = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.CutToolStripButton.Size = New System.Drawing.Size(24, 22)
        Me.CutToolStripButton.Text = "C&ut"
        '
        'CopyToolStripButton
        '
        Me.CopyToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CopyToolStripButton.Image = CType(resources.GetObject("CopyToolStripButton.Image"), System.Drawing.Image)
        Me.CopyToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CopyToolStripButton.Name = "CopyToolStripButton"
        Me.CopyToolStripButton.Padding = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.CopyToolStripButton.Size = New System.Drawing.Size(24, 22)
        Me.CopyToolStripButton.Text = "&Copy"
        '
        'PasteToolStripButton
        '
        Me.PasteToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PasteToolStripButton.Image = CType(resources.GetObject("PasteToolStripButton.Image"), System.Drawing.Image)
        Me.PasteToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PasteToolStripButton.Name = "PasteToolStripButton"
        Me.PasteToolStripButton.Padding = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.PasteToolStripButton.Size = New System.Drawing.Size(24, 22)
        Me.PasteToolStripButton.Text = "&Paste"
        '
        'ToolStripButton6
        '
        Me.ToolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton6.Image = Global.scramble.My.Resources.Resources.accept
        Me.ToolStripButton6.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton6.Name = "ToolStripButton6"
        Me.ToolStripButton6.Padding = New System.Windows.Forms.Padding(2)
        Me.ToolStripButton6.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton6.Text = "select all"
        '
        'toolStripSeparator31
        '
        Me.toolStripSeparator31.Name = "toolStripSeparator31"
        Me.toolStripSeparator31.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton2.Image = Global.scramble.My.Resources.Resources.arrow_dropdown
        Me.ToolStripButton2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton2.Text = "ToolStripButton2"
        Me.ToolStripButton2.ToolTipText = "Toggle output window"
        '
        'ToolStripTextBox1
        '
        Me.ToolStripTextBox1.Name = "ToolStripTextBox1"
        Me.ToolStripTextBox1.Padding = New System.Windows.Forms.Padding(0, 0, 3, 0)
        Me.ToolStripTextBox1.Size = New System.Drawing.Size(0, 25)
        Me.ToolStripTextBox1.Text = "            font name          "
        Me.ToolStripTextBox1.Visible = False
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Margin = New System.Windows.Forms.Padding(1)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.Padding = New System.Drawing.Point(12, 1)
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(958, 103)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.TextBox1)
        Me.TabPage1.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage1.ForeColor = System.Drawing.Color.Black
        Me.TabPage1.Location = New System.Drawing.Point(4, 20)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(1)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(950, 79)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Output"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.SeaGreen
        Me.Label4.Dock = System.Windows.Forms.DockStyle.Right
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(761, 3)
        Me.Label4.Name = "Label4"
        Me.Label4.Padding = New System.Windows.Forms.Padding(4, 6, 45, 6)
        Me.Label4.Size = New System.Drawing.Size(99, 25)
        Me.Label4.TabIndex = 40
        Me.Label4.Text = "warnings"
        Me.Label4.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Firebrick
        Me.Label3.Dock = System.Windows.Forms.DockStyle.Right
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(860, 3)
        Me.Label3.Name = "Label3"
        Me.Label3.Padding = New System.Windows.Forms.Padding(6, 6, 45, 6)
        Me.Label3.Size = New System.Drawing.Size(87, 25)
        Me.Label3.TabIndex = 39
        Me.Label3.Text = "errors"
        Me.Label3.Visible = False
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.White
        Me.TextBox1.Cursor = System.Windows.Forms.Cursors.Default
        Me.TextBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.ForeColor = System.Drawing.Color.MidnightBlue
        Me.TextBox1.Location = New System.Drawing.Point(3, 3)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(1)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBox1.ShortcutsEnabled = False
        Me.TextBox1.Size = New System.Drawing.Size(944, 73)
        Me.TextBox1.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.DocWebBrowser1)
        Me.TabPage2.Controls.Add(Me.DocLaunchrTextBox2)
        Me.TabPage2.Controls.Add(Me.ToolStrip2)
        Me.TabPage2.ForeColor = System.Drawing.Color.Black
        Me.TabPage2.Location = New System.Drawing.Point(4, 20)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(950, 79)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Document Viewer"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'DocWebBrowser1
        '
        Me.DocWebBrowser1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DocWebBrowser1.Location = New System.Drawing.Point(3, 25)
        Me.DocWebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.DocWebBrowser1.Name = "DocWebBrowser1"
        Me.DocWebBrowser1.Size = New System.Drawing.Size(920, 51)
        Me.DocWebBrowser1.TabIndex = 2
        '
        'DocLaunchrTextBox2
        '
        Me.DocLaunchrTextBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.DocLaunchrTextBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.AllSystemSources
        Me.DocLaunchrTextBox2.BackColor = System.Drawing.Color.White
        Me.DocLaunchrTextBox2.Dock = System.Windows.Forms.DockStyle.Top
        Me.DocLaunchrTextBox2.ForeColor = System.Drawing.Color.Black
        Me.DocLaunchrTextBox2.Location = New System.Drawing.Point(3, 3)
        Me.DocLaunchrTextBox2.Name = "DocLaunchrTextBox2"
        Me.DocLaunchrTextBox2.Size = New System.Drawing.Size(920, 22)
        Me.DocLaunchrTextBox2.TabIndex = 1
        '
        'ToolStrip2
        '
        Me.ToolStrip2.Dock = System.Windows.Forms.DockStyle.Right
        Me.ToolStrip2.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripButton1, Me.toolStripSeparator32, Me.SaveToolStripButton1, Me.PrintToolStripButton1, Me.backToolStripButton3, Me.fwdToolStripButton7, Me.stopToolStripButton8, Me.refreshToolStripButton9})
        Me.ToolStrip2.Location = New System.Drawing.Point(923, 3)
        Me.ToolStrip2.Name = "ToolStrip2"
        Me.ToolStrip2.Size = New System.Drawing.Size(24, 73)
        Me.ToolStrip2.TabIndex = 0
        Me.ToolStrip2.Text = "ToolStrip2"
        '
        'NewToolStripButton1
        '
        Me.NewToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.NewToolStripButton1.Image = CType(resources.GetObject("NewToolStripButton1.Image"), System.Drawing.Image)
        Me.NewToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NewToolStripButton1.Name = "NewToolStripButton1"
        Me.NewToolStripButton1.Size = New System.Drawing.Size(21, 20)
        Me.NewToolStripButton1.Text = "GO"
        Me.NewToolStripButton1.ToolTipText = "Go"
        '
        'toolStripSeparator32
        '
        Me.toolStripSeparator32.Name = "toolStripSeparator32"
        Me.toolStripSeparator32.Size = New System.Drawing.Size(21, 6)
        '
        'SaveToolStripButton1
        '
        Me.SaveToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SaveToolStripButton1.Image = CType(resources.GetObject("SaveToolStripButton1.Image"), System.Drawing.Image)
        Me.SaveToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SaveToolStripButton1.Name = "SaveToolStripButton1"
        Me.SaveToolStripButton1.Size = New System.Drawing.Size(21, 20)
        Me.SaveToolStripButton1.Text = "&Save"
        '
        'PrintToolStripButton1
        '
        Me.PrintToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PrintToolStripButton1.Image = CType(resources.GetObject("PrintToolStripButton1.Image"), System.Drawing.Image)
        Me.PrintToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PrintToolStripButton1.Name = "PrintToolStripButton1"
        Me.PrintToolStripButton1.Size = New System.Drawing.Size(23, 20)
        Me.PrintToolStripButton1.Text = "&Print"
        '
        'backToolStripButton3
        '
        Me.backToolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.backToolStripButton3.Image = CType(resources.GetObject("backToolStripButton3.Image"), System.Drawing.Image)
        Me.backToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.backToolStripButton3.Name = "backToolStripButton3"
        Me.backToolStripButton3.Size = New System.Drawing.Size(23, 19)
        Me.backToolStripButton3.Text = "<"
        '
        'fwdToolStripButton7
        '
        Me.fwdToolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.fwdToolStripButton7.Image = CType(resources.GetObject("fwdToolStripButton7.Image"), System.Drawing.Image)
        Me.fwdToolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.fwdToolStripButton7.Name = "fwdToolStripButton7"
        Me.fwdToolStripButton7.Size = New System.Drawing.Size(23, 19)
        Me.fwdToolStripButton7.Text = ">"
        '
        'stopToolStripButton8
        '
        Me.stopToolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.stopToolStripButton8.Enabled = False
        Me.stopToolStripButton8.Image = CType(resources.GetObject("stopToolStripButton8.Image"), System.Drawing.Image)
        Me.stopToolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.stopToolStripButton8.Name = "stopToolStripButton8"
        Me.stopToolStripButton8.Size = New System.Drawing.Size(23, 19)
        Me.stopToolStripButton8.Text = "x"
        '
        'refreshToolStripButton9
        '
        Me.refreshToolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.refreshToolStripButton9.Enabled = False
        Me.refreshToolStripButton9.Image = CType(resources.GetObject("refreshToolStripButton9.Image"), System.Drawing.Image)
        Me.refreshToolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.refreshToolStripButton9.Name = "refreshToolStripButton9"
        Me.refreshToolStripButton9.Size = New System.Drawing.Size(23, 19)
        Me.refreshToolStripButton9.Text = "R"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Green
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HelpToolStripMenuItem, Me.ToolStripTextBox2, Me.ToolStripTextBox7, Me.SaveToolStripMenuItem4, Me.CompileToolStripMenuItem, Me.executeToolStripMenuItem1, Me.DashboardToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(958, 26)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.BackColor = System.Drawing.Color.DarkGreen
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ToolStripSeparator1, Me.ExitToolStripMenuItem})
        Me.HelpToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Padding = New System.Windows.Forms.Padding(4, 2, 4, 2)
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(70, 22)
        Me.HelpToolStripMenuItem.Text = "bytespace"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem, Me.OpenToolStripMenuItem, Me.SaveToolStripMenuItem5})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(92, 22)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'NewToolStripMenuItem
        '
        Me.NewToolStripMenuItem.Name = "NewToolStripMenuItem"
        Me.NewToolStripMenuItem.Size = New System.Drawing.Size(103, 22)
        Me.NewToolStripMenuItem.Text = "New"
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(103, 22)
        Me.OpenToolStripMenuItem.Text = "Open"
        '
        'SaveToolStripMenuItem5
        '
        Me.SaveToolStripMenuItem5.Name = "SaveToolStripMenuItem5"
        Me.SaveToolStripMenuItem5.Size = New System.Drawing.Size(103, 22)
        Me.SaveToolStripMenuItem5.Text = "Save"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(89, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(92, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'ToolStripTextBox2
        '
        Me.ToolStripTextBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.ToolStripTextBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystem
        Me.ToolStripTextBox2.BackColor = System.Drawing.Color.Green
        Me.ToolStripTextBox2.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripTextBox2.ForeColor = System.Drawing.Color.White
        Me.ToolStripTextBox2.Name = "ToolStripTextBox2"
        Me.ToolStripTextBox2.Size = New System.Drawing.Size(200, 22)
        Me.ToolStripTextBox2.Text = "file_name"
        '
        'ToolStripTextBox7
        '
        Me.ToolStripTextBox7.BackColor = System.Drawing.Color.Green
        Me.ToolStripTextBox7.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripTextBox7.ForeColor = System.Drawing.Color.White
        Me.ToolStripTextBox7.Name = "ToolStripTextBox7"
        Me.ToolStripTextBox7.Size = New System.Drawing.Size(200, 22)
        Me.ToolStripTextBox7.Text = "arguments"
        '
        'SaveToolStripMenuItem4
        '
        Me.SaveToolStripMenuItem4.ForeColor = System.Drawing.Color.AliceBlue
        Me.SaveToolStripMenuItem4.Name = "SaveToolStripMenuItem4"
        Me.SaveToolStripMenuItem4.ShortcutKeys = System.Windows.Forms.Keys.F7
        Me.SaveToolStripMenuItem4.Size = New System.Drawing.Size(61, 22)
        Me.SaveToolStripMenuItem4.Text = "Save file"
        '
        'CompileToolStripMenuItem
        '
        Me.CompileToolStripMenuItem.Enabled = False
        Me.CompileToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CompileToolStripMenuItem.ForeColor = System.Drawing.Color.AliceBlue
        Me.CompileToolStripMenuItem.Name = "CompileToolStripMenuItem"
        Me.CompileToolStripMenuItem.Size = New System.Drawing.Size(46, 22)
        Me.CompileToolStripMenuItem.Text = "build"
        '
        'executeToolStripMenuItem1
        '
        Me.executeToolStripMenuItem1.Enabled = False
        Me.executeToolStripMenuItem1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.executeToolStripMenuItem1.ForeColor = System.Drawing.Color.AliceBlue
        Me.executeToolStripMenuItem1.Name = "executeToolStripMenuItem1"
        Me.executeToolStripMenuItem1.Size = New System.Drawing.Size(28, 22)
        Me.executeToolStripMenuItem1.Text = "u"
        '
        'DashboardToolStripMenuItem
        '
        Me.DashboardToolStripMenuItem.ForeColor = System.Drawing.Color.AliceBlue
        Me.DashboardToolStripMenuItem.Name = "DashboardToolStripMenuItem"
        Me.DashboardToolStripMenuItem.Size = New System.Drawing.Size(76, 22)
        Me.DashboardToolStripMenuItem.Text = "Dashboard"
        '
        'MenuStrip2
        '
        Me.MenuStrip2.BackColor = System.Drawing.Color.Tomato
        Me.MenuStrip2.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip2.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem19, Me.ToolStripTextBox3, Me.ToolStripTextBox8, Me.SaveToolStripMenuItem3, Me.CompileToolStripMenuItem1, Me.executeJv_ToolStripMenuItem2, Me.DashboardToolStripMenuItem1})
        Me.MenuStrip2.Location = New System.Drawing.Point(0, 106)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(958, 27)
        Me.MenuStrip2.TabIndex = 1
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'ToolStripMenuItem19
        '
        Me.ToolStripMenuItem19.BackColor = System.Drawing.Color.Transparent
        Me.ToolStripMenuItem19.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem1, Me.ToolStripSeparator2, Me.ExitToolStripMenuItem1})
        Me.ToolStripMenuItem19.ForeColor = System.Drawing.Color.White
        Me.ToolStripMenuItem19.Name = "ToolStripMenuItem19"
        Me.ToolStripMenuItem19.Size = New System.Drawing.Size(70, 23)
        Me.ToolStripMenuItem19.Text = "bytespace"
        '
        'FileToolStripMenuItem1
        '
        Me.FileToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem1, Me.SaveToolStripMenuItem6, Me.OpenToolStripMenuItem1})
        Me.FileToolStripMenuItem1.Name = "FileToolStripMenuItem1"
        Me.FileToolStripMenuItem1.Size = New System.Drawing.Size(92, 22)
        Me.FileToolStripMenuItem1.Text = "File"
        '
        'NewToolStripMenuItem1
        '
        Me.NewToolStripMenuItem1.Name = "NewToolStripMenuItem1"
        Me.NewToolStripMenuItem1.Size = New System.Drawing.Size(103, 22)
        Me.NewToolStripMenuItem1.Text = "New"
        '
        'SaveToolStripMenuItem6
        '
        Me.SaveToolStripMenuItem6.Name = "SaveToolStripMenuItem6"
        Me.SaveToolStripMenuItem6.Size = New System.Drawing.Size(103, 22)
        Me.SaveToolStripMenuItem6.Text = "Save"
        '
        'OpenToolStripMenuItem1
        '
        Me.OpenToolStripMenuItem1.Name = "OpenToolStripMenuItem1"
        Me.OpenToolStripMenuItem1.Size = New System.Drawing.Size(103, 22)
        Me.OpenToolStripMenuItem1.Text = "Open"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(89, 6)
        '
        'ExitToolStripMenuItem1
        '
        Me.ExitToolStripMenuItem1.Name = "ExitToolStripMenuItem1"
        Me.ExitToolStripMenuItem1.Size = New System.Drawing.Size(92, 22)
        Me.ExitToolStripMenuItem1.Text = "Exit"
        '
        'ToolStripTextBox3
        '
        Me.ToolStripTextBox3.BackColor = System.Drawing.Color.Tomato
        Me.ToolStripTextBox3.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripTextBox3.ForeColor = System.Drawing.Color.White
        Me.ToolStripTextBox3.Name = "ToolStripTextBox3"
        Me.ToolStripTextBox3.Size = New System.Drawing.Size(200, 23)
        Me.ToolStripTextBox3.Text = "file_name"
        '
        'ToolStripTextBox8
        '
        Me.ToolStripTextBox8.BackColor = System.Drawing.Color.Tomato
        Me.ToolStripTextBox8.ForeColor = System.Drawing.Color.White
        Me.ToolStripTextBox8.Name = "ToolStripTextBox8"
        Me.ToolStripTextBox8.Size = New System.Drawing.Size(200, 23)
        Me.ToolStripTextBox8.Text = "arguments"
        '
        'SaveToolStripMenuItem3
        '
        Me.SaveToolStripMenuItem3.BackColor = System.Drawing.Color.Transparent
        Me.SaveToolStripMenuItem3.ForeColor = System.Drawing.Color.White
        Me.SaveToolStripMenuItem3.Name = "SaveToolStripMenuItem3"
        Me.SaveToolStripMenuItem3.Size = New System.Drawing.Size(61, 23)
        Me.SaveToolStripMenuItem3.Text = "Save file"
        '
        'CompileToolStripMenuItem1
        '
        Me.CompileToolStripMenuItem1.ForeColor = System.Drawing.Color.White
        Me.CompileToolStripMenuItem1.Name = "CompileToolStripMenuItem1"
        Me.CompileToolStripMenuItem1.Size = New System.Drawing.Size(61, 23)
        Me.CompileToolStripMenuItem1.Text = "Compile"
        '
        'executeJv_ToolStripMenuItem2
        '
        Me.executeJv_ToolStripMenuItem2.Enabled = False
        Me.executeJv_ToolStripMenuItem2.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.executeJv_ToolStripMenuItem2.ForeColor = System.Drawing.Color.SteelBlue
        Me.executeJv_ToolStripMenuItem2.Name = "executeJv_ToolStripMenuItem2"
        Me.executeJv_ToolStripMenuItem2.ShortcutKeys = System.Windows.Forms.Keys.F9
        Me.executeJv_ToolStripMenuItem2.Size = New System.Drawing.Size(28, 23)
        Me.executeJv_ToolStripMenuItem2.Text = "u"
        '
        'DashboardToolStripMenuItem1
        '
        Me.DashboardToolStripMenuItem1.ForeColor = System.Drawing.Color.White
        Me.DashboardToolStripMenuItem1.Name = "DashboardToolStripMenuItem1"
        Me.DashboardToolStripMenuItem1.Size = New System.Drawing.Size(76, 23)
        Me.DashboardToolStripMenuItem1.Text = "Dashboard"
        '
        'MenuStrip3
        '
        Me.MenuStrip3.BackColor = System.Drawing.Color.CadetBlue
        Me.MenuStrip3.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip3.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip3.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem42, Me.ToolStripTextBox4, Me.CompileToolStripMenuItem2, Me.MakeToolStripMenuItem, Me.BurnToolStripMenuItem, Me.SaveToolStripMenuItem2, Me.DashboardToolStripMenuItem2})
        Me.MenuStrip3.Location = New System.Drawing.Point(0, 26)
        Me.MenuStrip3.Name = "MenuStrip3"
        Me.MenuStrip3.Size = New System.Drawing.Size(958, 27)
        Me.MenuStrip3.TabIndex = 2
        Me.MenuStrip3.Text = "MenuStrip3"
        '
        'ToolStripMenuItem42
        '
        Me.ToolStripMenuItem42.BackColor = System.Drawing.Color.CadetBlue
        Me.ToolStripMenuItem42.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem2, Me.ToolStripSeparator3, Me.ToolStripMenuItem43, Me.ToolStripMenuItem44, Me.ToolStripMenuItem45, Me.ToolStripSeparator17, Me.ToolStripMenuItem46})
        Me.ToolStripMenuItem42.ForeColor = System.Drawing.Color.White
        Me.ToolStripMenuItem42.Name = "ToolStripMenuItem42"
        Me.ToolStripMenuItem42.Size = New System.Drawing.Size(70, 23)
        Me.ToolStripMenuItem42.Text = "bytespace"
        '
        'FileToolStripMenuItem2
        '
        Me.FileToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem2, Me.SaveToolStripMenuItem7, Me.OpenToolStripMenuItem2})
        Me.FileToolStripMenuItem2.Name = "FileToolStripMenuItem2"
        Me.FileToolStripMenuItem2.Size = New System.Drawing.Size(138, 22)
        Me.FileToolStripMenuItem2.Text = "File"
        '
        'NewToolStripMenuItem2
        '
        Me.NewToolStripMenuItem2.Name = "NewToolStripMenuItem2"
        Me.NewToolStripMenuItem2.Size = New System.Drawing.Size(103, 22)
        Me.NewToolStripMenuItem2.Text = "New"
        '
        'SaveToolStripMenuItem7
        '
        Me.SaveToolStripMenuItem7.Name = "SaveToolStripMenuItem7"
        Me.SaveToolStripMenuItem7.Size = New System.Drawing.Size(103, 22)
        Me.SaveToolStripMenuItem7.Text = "Save"
        '
        'OpenToolStripMenuItem2
        '
        Me.OpenToolStripMenuItem2.Name = "OpenToolStripMenuItem2"
        Me.OpenToolStripMenuItem2.Size = New System.Drawing.Size(103, 22)
        Me.OpenToolStripMenuItem2.Text = "Open"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(135, 6)
        '
        'ToolStripMenuItem43
        '
        Me.ToolStripMenuItem43.Name = "ToolStripMenuItem43"
        Me.ToolStripMenuItem43.Size = New System.Drawing.Size(138, 22)
        Me.ToolStripMenuItem43.Text = "&Contents"
        '
        'ToolStripMenuItem44
        '
        Me.ToolStripMenuItem44.Name = "ToolStripMenuItem44"
        Me.ToolStripMenuItem44.Size = New System.Drawing.Size(138, 22)
        Me.ToolStripMenuItem44.Text = "&Index"
        '
        'ToolStripMenuItem45
        '
        Me.ToolStripMenuItem45.Name = "ToolStripMenuItem45"
        Me.ToolStripMenuItem45.Size = New System.Drawing.Size(138, 22)
        Me.ToolStripMenuItem45.Text = "&Search"
        '
        'ToolStripSeparator17
        '
        Me.ToolStripSeparator17.Name = "ToolStripSeparator17"
        Me.ToolStripSeparator17.Size = New System.Drawing.Size(135, 6)
        '
        'ToolStripMenuItem46
        '
        Me.ToolStripMenuItem46.Name = "ToolStripMenuItem46"
        Me.ToolStripMenuItem46.Size = New System.Drawing.Size(138, 22)
        Me.ToolStripMenuItem46.Text = "&About...avr c"
        '
        'ToolStripTextBox4
        '
        Me.ToolStripTextBox4.BackColor = System.Drawing.Color.CadetBlue
        Me.ToolStripTextBox4.ForeColor = System.Drawing.Color.White
        Me.ToolStripTextBox4.Name = "ToolStripTextBox4"
        Me.ToolStripTextBox4.Size = New System.Drawing.Size(200, 23)
        Me.ToolStripTextBox4.Text = "file_name"
        '
        'CompileToolStripMenuItem2
        '
        Me.CompileToolStripMenuItem2.ForeColor = System.Drawing.Color.Black
        Me.CompileToolStripMenuItem2.Name = "CompileToolStripMenuItem2"
        Me.CompileToolStripMenuItem2.Size = New System.Drawing.Size(46, 23)
        Me.CompileToolStripMenuItem2.Text = "Build"
        '
        'MakeToolStripMenuItem
        '
        Me.MakeToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.MakeToolStripMenuItem.Name = "MakeToolStripMenuItem"
        Me.MakeToolStripMenuItem.Size = New System.Drawing.Size(47, 23)
        Me.MakeToolStripMenuItem.Text = "Make"
        '
        'BurnToolStripMenuItem
        '
        Me.BurnToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.BurnToolStripMenuItem.Name = "BurnToolStripMenuItem"
        Me.BurnToolStripMenuItem.Size = New System.Drawing.Size(44, 23)
        Me.BurnToolStripMenuItem.Text = "Burn"
        '
        'SaveToolStripMenuItem2
        '
        Me.SaveToolStripMenuItem2.ForeColor = System.Drawing.Color.Black
        Me.SaveToolStripMenuItem2.Name = "SaveToolStripMenuItem2"
        Me.SaveToolStripMenuItem2.Size = New System.Drawing.Size(61, 23)
        Me.SaveToolStripMenuItem2.Text = "Save file"
        '
        'DashboardToolStripMenuItem2
        '
        Me.DashboardToolStripMenuItem2.ForeColor = System.Drawing.Color.Black
        Me.DashboardToolStripMenuItem2.Name = "DashboardToolStripMenuItem2"
        Me.DashboardToolStripMenuItem2.Size = New System.Drawing.Size(76, 23)
        Me.DashboardToolStripMenuItem2.Text = "Dashboard"
        '
        'MenuStrip4
        '
        Me.MenuStrip4.BackColor = System.Drawing.Color.SteelBlue
        Me.MenuStrip4.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip4.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip4.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem88, Me.ToolStripTextBox5, Me.BuildToolStripMenuItem, Me.MakeToolStripMenuItem1, Me.BurnToolStripMenuItem1, Me.SaveToolStripMenuItem1, Me.ToolStripComboBox1, Me.ToolStripComboBox2, Me.ToolStripComboBox3, Me.DashboardToolStripMenuItem3})
        Me.MenuStrip4.Location = New System.Drawing.Point(0, 53)
        Me.MenuStrip4.Name = "MenuStrip4"
        Me.MenuStrip4.Size = New System.Drawing.Size(958, 27)
        Me.MenuStrip4.TabIndex = 4
        Me.MenuStrip4.Text = "MenuStrip5"
        '
        'ToolStripMenuItem88
        '
        Me.ToolStripMenuItem88.BackColor = System.Drawing.Color.SteelBlue
        Me.ToolStripMenuItem88.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem3, Me.ToolStripSeparator4, Me.ToolStripMenuItem89, Me.ToolStripMenuItem90, Me.ToolStripMenuItem91, Me.ToolStripSeparator29, Me.OptionsToolStripMenuItem2, Me.ToolStripSeparator7, Me.ToolStripMenuItem92})
        Me.ToolStripMenuItem88.ForeColor = System.Drawing.Color.White
        Me.ToolStripMenuItem88.Name = "ToolStripMenuItem88"
        Me.ToolStripMenuItem88.Size = New System.Drawing.Size(70, 23)
        Me.ToolStripMenuItem88.Text = "bytespace"
        '
        'FileToolStripMenuItem3
        '
        Me.FileToolStripMenuItem3.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem3, Me.SaveToolStripMenuItem8, Me.OpenToolStripMenuItem3})
        Me.FileToolStripMenuItem3.Name = "FileToolStripMenuItem3"
        Me.FileToolStripMenuItem3.Size = New System.Drawing.Size(176, 22)
        Me.FileToolStripMenuItem3.Text = "File"
        '
        'NewToolStripMenuItem3
        '
        Me.NewToolStripMenuItem3.Name = "NewToolStripMenuItem3"
        Me.NewToolStripMenuItem3.Size = New System.Drawing.Size(103, 22)
        Me.NewToolStripMenuItem3.Text = "New"
        '
        'SaveToolStripMenuItem8
        '
        Me.SaveToolStripMenuItem8.Name = "SaveToolStripMenuItem8"
        Me.SaveToolStripMenuItem8.Size = New System.Drawing.Size(103, 22)
        Me.SaveToolStripMenuItem8.Text = "Save"
        '
        'OpenToolStripMenuItem3
        '
        Me.OpenToolStripMenuItem3.Name = "OpenToolStripMenuItem3"
        Me.OpenToolStripMenuItem3.Size = New System.Drawing.Size(103, 22)
        Me.OpenToolStripMenuItem3.Text = "Open"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(173, 6)
        '
        'ToolStripMenuItem89
        '
        Me.ToolStripMenuItem89.Name = "ToolStripMenuItem89"
        Me.ToolStripMenuItem89.Size = New System.Drawing.Size(176, 22)
        Me.ToolStripMenuItem89.Text = "&Contents"
        '
        'ToolStripMenuItem90
        '
        Me.ToolStripMenuItem90.Name = "ToolStripMenuItem90"
        Me.ToolStripMenuItem90.Size = New System.Drawing.Size(176, 22)
        Me.ToolStripMenuItem90.Text = "&Index"
        '
        'ToolStripMenuItem91
        '
        Me.ToolStripMenuItem91.Name = "ToolStripMenuItem91"
        Me.ToolStripMenuItem91.Size = New System.Drawing.Size(176, 22)
        Me.ToolStripMenuItem91.Text = "&Search"
        '
        'ToolStripSeparator29
        '
        Me.ToolStripSeparator29.Name = "ToolStripSeparator29"
        Me.ToolStripSeparator29.Size = New System.Drawing.Size(173, 6)
        '
        'OptionsToolStripMenuItem2
        '
        Me.OptionsToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripComboBox4, Me.EraseChipToolStripMenuItem, Me.VerifyDeviceSignatureToolStripMenuItem, Me.PreventWritingToDeviceToolStripMenuItem, Me.DisableOutputToolStripMenuItem, Me.TerminalModeToolStripMenuItem, Me.VerboseModeToolStripMenuItem, Me.PreventVerificationCheckToolStripMenuItem, Me.FlashToolStripMenuItem, Me.EEPROMToolStripMenuItem, Me.FuseToolStripMenuItem, Me.ExitModeToolStripMenuItem, Me.CalibrationToolStripMenuItem})
        Me.OptionsToolStripMenuItem2.Name = "OptionsToolStripMenuItem2"
        Me.OptionsToolStripMenuItem2.Size = New System.Drawing.Size(176, 22)
        Me.OptionsToolStripMenuItem2.Text = "AVR Device Options"
        '
        'ToolStripComboBox4
        '
        Me.ToolStripComboBox4.CheckOnClick = True
        Me.ToolStripComboBox4.Name = "ToolStripComboBox4"
        Me.ToolStripComboBox4.Size = New System.Drawing.Size(243, 22)
        Me.ToolStripComboBox4.Text = "Disable Flash memory Auto erase"
        '
        'EraseChipToolStripMenuItem
        '
        Me.EraseChipToolStripMenuItem.Name = "EraseChipToolStripMenuItem"
        Me.EraseChipToolStripMenuItem.Size = New System.Drawing.Size(243, 22)
        Me.EraseChipToolStripMenuItem.Text = "Erase Chip"
        '
        'VerifyDeviceSignatureToolStripMenuItem
        '
        Me.VerifyDeviceSignatureToolStripMenuItem.Name = "VerifyDeviceSignatureToolStripMenuItem"
        Me.VerifyDeviceSignatureToolStripMenuItem.Size = New System.Drawing.Size(243, 22)
        Me.VerifyDeviceSignatureToolStripMenuItem.Text = "Verify Device Signature"
        '
        'PreventWritingToDeviceToolStripMenuItem
        '
        Me.PreventWritingToDeviceToolStripMenuItem.Name = "PreventWritingToDeviceToolStripMenuItem"
        Me.PreventWritingToDeviceToolStripMenuItem.Size = New System.Drawing.Size(243, 22)
        Me.PreventWritingToDeviceToolStripMenuItem.Text = "Prevent Writing to device"
        '
        'DisableOutputToolStripMenuItem
        '
        Me.DisableOutputToolStripMenuItem.Name = "DisableOutputToolStripMenuItem"
        Me.DisableOutputToolStripMenuItem.Size = New System.Drawing.Size(243, 22)
        Me.DisableOutputToolStripMenuItem.Text = "Disable process bar output"
        '
        'TerminalModeToolStripMenuItem
        '
        Me.TerminalModeToolStripMenuItem.Name = "TerminalModeToolStripMenuItem"
        Me.TerminalModeToolStripMenuItem.Size = New System.Drawing.Size(243, 22)
        Me.TerminalModeToolStripMenuItem.Text = "Terminal Mode"
        '
        'VerboseModeToolStripMenuItem
        '
        Me.VerboseModeToolStripMenuItem.Name = "VerboseModeToolStripMenuItem"
        Me.VerboseModeToolStripMenuItem.Size = New System.Drawing.Size(243, 22)
        Me.VerboseModeToolStripMenuItem.Text = "Verbose Mode"
        '
        'PreventVerificationCheckToolStripMenuItem
        '
        Me.PreventVerificationCheckToolStripMenuItem.Name = "PreventVerificationCheckToolStripMenuItem"
        Me.PreventVerificationCheckToolStripMenuItem.Size = New System.Drawing.Size(243, 22)
        Me.PreventVerificationCheckToolStripMenuItem.Text = "Prevent Verification check"
        '
        'FlashToolStripMenuItem
        '
        Me.FlashToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.WriteToolStripMenuItem1, Me.ReadToolStripMenuItem1, Me.VerifyToolStripMenuItem1})
        Me.FlashToolStripMenuItem.Name = "FlashToolStripMenuItem"
        Me.FlashToolStripMenuItem.Size = New System.Drawing.Size(243, 22)
        Me.FlashToolStripMenuItem.Text = "Flash"
        '
        'WriteToolStripMenuItem1
        '
        Me.WriteToolStripMenuItem1.Name = "WriteToolStripMenuItem1"
        Me.WriteToolStripMenuItem1.Size = New System.Drawing.Size(103, 22)
        Me.WriteToolStripMenuItem1.Text = "Write"
        '
        'ReadToolStripMenuItem1
        '
        Me.ReadToolStripMenuItem1.Name = "ReadToolStripMenuItem1"
        Me.ReadToolStripMenuItem1.Size = New System.Drawing.Size(103, 22)
        Me.ReadToolStripMenuItem1.Text = "Read"
        '
        'VerifyToolStripMenuItem1
        '
        Me.VerifyToolStripMenuItem1.Name = "VerifyToolStripMenuItem1"
        Me.VerifyToolStripMenuItem1.Size = New System.Drawing.Size(103, 22)
        Me.VerifyToolStripMenuItem1.Text = "Verify"
        '
        'EEPROMToolStripMenuItem
        '
        Me.EEPROMToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.WriteToolStripMenuItem, Me.ReadToolStripMenuItem, Me.VerifyToolStripMenuItem})
        Me.EEPROMToolStripMenuItem.Name = "EEPROMToolStripMenuItem"
        Me.EEPROMToolStripMenuItem.Size = New System.Drawing.Size(243, 22)
        Me.EEPROMToolStripMenuItem.Text = "EEPROM"
        '
        'WriteToolStripMenuItem
        '
        Me.WriteToolStripMenuItem.Name = "WriteToolStripMenuItem"
        Me.WriteToolStripMenuItem.Size = New System.Drawing.Size(103, 22)
        Me.WriteToolStripMenuItem.Text = "Write"
        '
        'ReadToolStripMenuItem
        '
        Me.ReadToolStripMenuItem.Name = "ReadToolStripMenuItem"
        Me.ReadToolStripMenuItem.Size = New System.Drawing.Size(103, 22)
        Me.ReadToolStripMenuItem.Text = "Read"
        '
        'VerifyToolStripMenuItem
        '
        Me.VerifyToolStripMenuItem.Name = "VerifyToolStripMenuItem"
        Me.VerifyToolStripMenuItem.Size = New System.Drawing.Size(103, 22)
        Me.VerifyToolStripMenuItem.Text = "Verify"
        '
        'FuseToolStripMenuItem
        '
        Me.FuseToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LowToolStripMenuItem, Me.HighToolStripMenuItem, Me.LockToolStripMenuItem, Me.ExtendedToolStripMenuItem})
        Me.FuseToolStripMenuItem.Name = "FuseToolStripMenuItem"
        Me.FuseToolStripMenuItem.Size = New System.Drawing.Size(243, 22)
        Me.FuseToolStripMenuItem.Text = "Fuse"
        '
        'LowToolStripMenuItem
        '
        Me.LowToolStripMenuItem.Name = "LowToolStripMenuItem"
        Me.LowToolStripMenuItem.Size = New System.Drawing.Size(122, 22)
        Me.LowToolStripMenuItem.Text = "Low"
        '
        'HighToolStripMenuItem
        '
        Me.HighToolStripMenuItem.Name = "HighToolStripMenuItem"
        Me.HighToolStripMenuItem.Size = New System.Drawing.Size(122, 22)
        Me.HighToolStripMenuItem.Text = "High"
        '
        'LockToolStripMenuItem
        '
        Me.LockToolStripMenuItem.Name = "LockToolStripMenuItem"
        Me.LockToolStripMenuItem.Size = New System.Drawing.Size(122, 22)
        Me.LockToolStripMenuItem.Text = "Lock"
        '
        'ExtendedToolStripMenuItem
        '
        Me.ExtendedToolStripMenuItem.Name = "ExtendedToolStripMenuItem"
        Me.ExtendedToolStripMenuItem.Size = New System.Drawing.Size(122, 22)
        Me.ExtendedToolStripMenuItem.Text = "Extended"
        '
        'ExitModeToolStripMenuItem
        '
        Me.ExitModeToolStripMenuItem.Name = "ExitModeToolStripMenuItem"
        Me.ExitModeToolStripMenuItem.Size = New System.Drawing.Size(243, 22)
        Me.ExitModeToolStripMenuItem.Text = "Exit Mode"
        '
        'CalibrationToolStripMenuItem
        '
        Me.CalibrationToolStripMenuItem.Name = "CalibrationToolStripMenuItem"
        Me.CalibrationToolStripMenuItem.Size = New System.Drawing.Size(243, 22)
        Me.CalibrationToolStripMenuItem.Text = "Calibration"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(173, 6)
        '
        'ToolStripMenuItem92
        '
        Me.ToolStripMenuItem92.Name = "ToolStripMenuItem92"
        Me.ToolStripMenuItem92.Size = New System.Drawing.Size(176, 22)
        Me.ToolStripMenuItem92.Text = "&About...avr gcc"
        '
        'ToolStripTextBox5
        '
        Me.ToolStripTextBox5.BackColor = System.Drawing.Color.SteelBlue
        Me.ToolStripTextBox5.ForeColor = System.Drawing.Color.White
        Me.ToolStripTextBox5.Name = "ToolStripTextBox5"
        Me.ToolStripTextBox5.Size = New System.Drawing.Size(200, 23)
        Me.ToolStripTextBox5.Text = "file_name"
        '
        'BuildToolStripMenuItem
        '
        Me.BuildToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.BuildToolStripMenuItem.Name = "BuildToolStripMenuItem"
        Me.BuildToolStripMenuItem.Size = New System.Drawing.Size(46, 23)
        Me.BuildToolStripMenuItem.Text = "Build"
        '
        'MakeToolStripMenuItem1
        '
        Me.MakeToolStripMenuItem1.ForeColor = System.Drawing.Color.Black
        Me.MakeToolStripMenuItem1.Name = "MakeToolStripMenuItem1"
        Me.MakeToolStripMenuItem1.Size = New System.Drawing.Size(47, 23)
        Me.MakeToolStripMenuItem1.Text = "Make"
        '
        'BurnToolStripMenuItem1
        '
        Me.BurnToolStripMenuItem1.ForeColor = System.Drawing.Color.Black
        Me.BurnToolStripMenuItem1.Name = "BurnToolStripMenuItem1"
        Me.BurnToolStripMenuItem1.Size = New System.Drawing.Size(44, 23)
        Me.BurnToolStripMenuItem1.Text = "Burn"
        '
        'SaveToolStripMenuItem1
        '
        Me.SaveToolStripMenuItem1.ForeColor = System.Drawing.Color.Black
        Me.SaveToolStripMenuItem1.Name = "SaveToolStripMenuItem1"
        Me.SaveToolStripMenuItem1.Size = New System.Drawing.Size(61, 23)
        Me.SaveToolStripMenuItem1.Text = "Save file"
        '
        'ToolStripComboBox1
        '
        Me.ToolStripComboBox1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripComboBox1.Name = "ToolStripComboBox1"
        Me.ToolStripComboBox1.Size = New System.Drawing.Size(121, 23)
        Me.ToolStripComboBox1.Text = "Device"
        '
        'ToolStripComboBox2
        '
        Me.ToolStripComboBox2.Name = "ToolStripComboBox2"
        Me.ToolStripComboBox2.Size = New System.Drawing.Size(121, 23)
        Me.ToolStripComboBox2.Text = "Programmer"
        '
        'ToolStripComboBox3
        '
        Me.ToolStripComboBox3.Name = "ToolStripComboBox3"
        Me.ToolStripComboBox3.Size = New System.Drawing.Size(121, 23)
        Me.ToolStripComboBox3.Text = "Port"
        '
        'DashboardToolStripMenuItem3
        '
        Me.DashboardToolStripMenuItem3.Name = "DashboardToolStripMenuItem3"
        Me.DashboardToolStripMenuItem3.Size = New System.Drawing.Size(76, 23)
        Me.DashboardToolStripMenuItem3.Text = "Dashboard"
        '
        'MenuStrip5
        '
        Me.MenuStrip5.BackColor = System.Drawing.Color.MediumPurple
        Me.MenuStrip5.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip5.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip5.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem65, Me.ToolStripTextBox6, Me.SaveToolStripMenuItem, Me.DashboardToolStripMenuItem4, Me.ToolStripMenuItem1, Me.CodeToolStripMenuItem})
        Me.MenuStrip5.Location = New System.Drawing.Point(0, 80)
        Me.MenuStrip5.Name = "MenuStrip5"
        Me.MenuStrip5.Size = New System.Drawing.Size(958, 26)
        Me.MenuStrip5.TabIndex = 3
        Me.MenuStrip5.Text = "MenuStrip4"
        '
        'ToolStripMenuItem65
        '
        Me.ToolStripMenuItem65.BackColor = System.Drawing.Color.MediumPurple
        Me.ToolStripMenuItem65.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem4, Me.ToolStripSeparator6, Me.ToolStripMenuItem69})
        Me.ToolStripMenuItem65.ForeColor = System.Drawing.Color.White
        Me.ToolStripMenuItem65.Name = "ToolStripMenuItem65"
        Me.ToolStripMenuItem65.Size = New System.Drawing.Size(70, 22)
        Me.ToolStripMenuItem65.Text = "bytespace"
        '
        'FileToolStripMenuItem4
        '
        Me.FileToolStripMenuItem4.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem4, Me.SaveToolStripMenuItem9, Me.OpenToolStripMenuItem4})
        Me.FileToolStripMenuItem4.Name = "FileToolStripMenuItem4"
        Me.FileToolStripMenuItem4.Size = New System.Drawing.Size(92, 22)
        Me.FileToolStripMenuItem4.Text = "File"
        '
        'NewToolStripMenuItem4
        '
        Me.NewToolStripMenuItem4.Name = "NewToolStripMenuItem4"
        Me.NewToolStripMenuItem4.Size = New System.Drawing.Size(103, 22)
        Me.NewToolStripMenuItem4.Text = "New"
        '
        'SaveToolStripMenuItem9
        '
        Me.SaveToolStripMenuItem9.Name = "SaveToolStripMenuItem9"
        Me.SaveToolStripMenuItem9.Size = New System.Drawing.Size(103, 22)
        Me.SaveToolStripMenuItem9.Text = "Save"
        '
        'OpenToolStripMenuItem4
        '
        Me.OpenToolStripMenuItem4.Name = "OpenToolStripMenuItem4"
        Me.OpenToolStripMenuItem4.Size = New System.Drawing.Size(103, 22)
        Me.OpenToolStripMenuItem4.Text = "Open"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(89, 6)
        '
        'ToolStripMenuItem69
        '
        Me.ToolStripMenuItem69.Name = "ToolStripMenuItem69"
        Me.ToolStripMenuItem69.Size = New System.Drawing.Size(92, 22)
        Me.ToolStripMenuItem69.Text = "Exit"
        '
        'ToolStripTextBox6
        '
        Me.ToolStripTextBox6.BackColor = System.Drawing.Color.MediumPurple
        Me.ToolStripTextBox6.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripTextBox6.ForeColor = System.Drawing.Color.White
        Me.ToolStripTextBox6.Name = "ToolStripTextBox6"
        Me.ToolStripTextBox6.Size = New System.Drawing.Size(100, 22)
        Me.ToolStripTextBox6.Text = "file_name.ext"
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(61, 22)
        Me.SaveToolStripMenuItem.Text = "Save file"
        '
        'DashboardToolStripMenuItem4
        '
        Me.DashboardToolStripMenuItem4.ForeColor = System.Drawing.Color.Black
        Me.DashboardToolStripMenuItem4.Name = "DashboardToolStripMenuItem4"
        Me.DashboardToolStripMenuItem4.Size = New System.Drawing.Size(76, 22)
        Me.DashboardToolStripMenuItem4.Text = "Dashboard"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.ForeColor = System.Drawing.Color.Black
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(39, 22)
        Me.ToolStripMenuItem1.Text = "title"
        '
        'CodeToolStripMenuItem
        '
        Me.CodeToolStripMenuItem.Name = "CodeToolStripMenuItem"
        Me.CodeToolStripMenuItem.Size = New System.Drawing.Size(46, 22)
        Me.CodeToolStripMenuItem.Text = "Code"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'PrintForm1
        '
        Me.PrintForm1.DocumentName = "document"
        Me.PrintForm1.Form = Me
        Me.PrintForm1.PrintAction = System.Drawing.Printing.PrintAction.PrintToPrinter
        Me.PrintForm1.PrinterSettings = CType(resources.GetObject("PrintForm1.PrinterSettings"), System.Drawing.Printing.PrinterSettings)
        Me.PrintForm1.PrintFileName = Nothing
        '
        'compile_TC_Process1
        '
        Me.compile_TC_Process1.StartInfo.Domain = ""
        Me.compile_TC_Process1.StartInfo.LoadUserProfile = False
        Me.compile_TC_Process1.StartInfo.Password = Nothing
        Me.compile_TC_Process1.StartInfo.StandardErrorEncoding = Nothing
        Me.compile_TC_Process1.StartInfo.StandardOutputEncoding = Nothing
        Me.compile_TC_Process1.StartInfo.UserName = ""
        Me.compile_TC_Process1.SynchronizingObject = Me
        '
        'PrintDialog1
        '
        Me.PrintDialog1.UseEXDialog = True
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 120000
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        '
        'execute_TC_Process2
        '
        Me.execute_TC_Process2.StartInfo.Domain = ""
        Me.execute_TC_Process2.StartInfo.LoadUserProfile = False
        Me.execute_TC_Process2.StartInfo.Password = Nothing
        Me.execute_TC_Process2.StartInfo.StandardErrorEncoding = Nothing
        Me.execute_TC_Process2.StartInfo.StandardOutputEncoding = Nothing
        Me.execute_TC_Process2.StartInfo.UserName = ""
        Me.execute_TC_Process2.SynchronizingObject = Me
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'Compile_JV_Process1
        '
        Me.Compile_JV_Process1.StartInfo.Domain = ""
        Me.Compile_JV_Process1.StartInfo.LoadUserProfile = False
        Me.Compile_JV_Process1.StartInfo.Password = Nothing
        Me.Compile_JV_Process1.StartInfo.StandardErrorEncoding = Nothing
        Me.Compile_JV_Process1.StartInfo.StandardOutputEncoding = Nothing
        Me.Compile_JV_Process1.StartInfo.UserName = ""
        Me.Compile_JV_Process1.StartInfo.UseShellExecute = False
        Me.Compile_JV_Process1.StartInfo.WorkingDirectory = "C:\Documents and Settings\sailesh\My Documents"
        Me.Compile_JV_Process1.SynchronizingObject = Me
        '
        'execute_JV_Process2
        '
        Me.execute_JV_Process2.StartInfo.Domain = ""
        Me.execute_JV_Process2.StartInfo.LoadUserProfile = False
        Me.execute_JV_Process2.StartInfo.Password = Nothing
        Me.execute_JV_Process2.StartInfo.StandardErrorEncoding = Nothing
        Me.execute_JV_Process2.StartInfo.StandardOutputEncoding = Nothing
        Me.execute_JV_Process2.StartInfo.UserName = ""
        Me.execute_JV_Process2.SynchronizingObject = Me
        '
        'BackgroundWorker1
        '
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(958, 557)
        Me.Controls.Add(Me.ToolStripContainer1)
        Me.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Black
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form5"
        Me.Text = "bytespace beta 1.0"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ToolStripContainer1.BottomToolStripPanel.ResumeLayout(False)
        Me.ToolStripContainer1.BottomToolStripPanel.PerformLayout()
        Me.ToolStripContainer1.ContentPanel.ResumeLayout(False)
        Me.ToolStripContainer1.TopToolStripPanel.ResumeLayout(False)
        Me.ToolStripContainer1.TopToolStripPanel.PerformLayout()
        Me.ToolStripContainer1.ResumeLayout(False)
        Me.ToolStripContainer1.PerformLayout()
        Me.ToolStrip3.ResumeLayout(False)
        Me.ToolStrip3.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.PerformLayout()
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.Panel2.PerformLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.ToolStrip2.ResumeLayout(False)
        Me.ToolStrip2.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        Me.MenuStrip3.ResumeLayout(False)
        Me.MenuStrip3.PerformLayout()
        Me.MenuStrip4.ResumeLayout(False)
        Me.MenuStrip4.PerformLayout()
        Me.MenuStrip5.ResumeLayout(False)
        Me.MenuStrip5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ToolStripContainer1 As System.Windows.Forms.ToolStripContainer
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents editorRichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents MenuStrip4 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem88 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem89 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem90 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem91 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator29 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripMenuItem92 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip5 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem65 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem69 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip3 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem42 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem43 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem44 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem45 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator17 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripMenuItem46 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip2 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem19 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents toolStripSeparator30 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CutToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents CopyToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents PasteToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents toolStripSeparator31 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents HelpToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripTextBox1 As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents DocWebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents DocLaunchrTextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents ToolStrip2 As System.Windows.Forms.ToolStrip
    Friend WithEvents NewToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents SaveToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents PrintToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents toolStripSeparator32 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents DashboardToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DashboardToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DashboardToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DashboardToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DashboardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BuildToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CompileToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CompileToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CompileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MakeToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BurnToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MakeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BurnToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripTextBox4 As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripTextBox3 As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripTextBox2 As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents NumericUpDown1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents ToolStripTextBox5 As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripTextBox6 As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStrip3 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents applauncher As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents AppLaunchrToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripLabel2 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripLabel3 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripLabel4 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripLabel5 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripTextBox7 As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripTextBox8 As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripButton4 As System.Windows.Forms.ToolStripButton
    Friend WithEvents FontDialog1 As System.Windows.Forms.FontDialog
    Friend WithEvents ToolStripLabel8 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton5 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton6 As System.Windows.Forms.ToolStripButton
    Friend WithEvents C_CPPtmplte As System.Windows.Forms.TextBox
    Friend WithEvents HtmlTemplte As System.Windows.Forms.TextBox
    Friend WithEvents ToolStripButton2 As System.Windows.Forms.ToolStripButton
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents FileToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem6 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents FileToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem7 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents FileToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem8 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents FileToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem9 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents PrintForm1 As Microsoft.VisualBasic.PowerPacks.Printing.PrintForm
    Friend WithEvents ToolStripComboBox1 As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ToolStripComboBox2 As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ToolStripComboBox3 As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents OptionsToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripComboBox4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents EraseChipToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VerifyDeviceSignatureToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PreventWritingToDeviceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DisableOutputToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TerminalModeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VerboseModeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PreventVerificationCheckToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FlashToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EEPROMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FuseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitModeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CalibrationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WriteToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReadToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VerifyToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WriteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VerifyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HighToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LockToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExtendedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents compile_TC_Process1 As System.Diagnostics.Process
    Friend WithEvents ToolStripLabel6 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents outpt_tmplte_TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents PrintDialog1 As System.Windows.Forms.PrintDialog
    Friend WithEvents RadioButton4 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents ToolStripLabel7 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents executeToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents execute_TC_Process2 As System.Diagnostics.Process
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ToolStripLabel9 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripLabel10 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents PrintPreviewDialog1 As System.Windows.Forms.PrintPreviewDialog
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ide_engine_WebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SaveToolStripButton As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents SaveToolStripMenuItem10 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveAsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrintToolStripButton As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents PrintOptionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrintPreviewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrintToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents OpenToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents executeJv_ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Compile_JV_Process1 As System.Diagnostics.Process
    Friend WithEvents execute_JV_Process2 As System.Diagnostics.Process
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents backToolStripButton3 As System.Windows.Forms.ToolStripButton
    Friend WithEvents fwdToolStripButton7 As System.Windows.Forms.ToolStripButton
    Friend WithEvents stopToolStripButton8 As System.Windows.Forms.ToolStripButton
    Friend WithEvents refreshToolStripButton9 As System.Windows.Forms.ToolStripButton
    Friend WithEvents CodeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents BackgroundWorker2 As System.ComponentModel.BackgroundWorker
End Class
